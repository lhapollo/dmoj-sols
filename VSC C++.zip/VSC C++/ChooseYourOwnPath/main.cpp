#include <bits/stdc++.h>
using namespace std;

queue<int> q;
bool visited[10001];
int dist[10001];

void bfs(vector<int> adj[], int x){
    visited[x-1] = true;
    dist[x-1] = 0;
    q.push(x-1);
    while (!q.empty()){
        int s = q.front(); 
        q.pop();

        for (auto u: adj[s]){
            if (visited[u-1]) continue;
            visited[u-1] = true;
            dist[u-1] = dist[s]+1;
            q.push(u-1);
        }
    }

}

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    vector<int> adj[n];
    for (int i = 0; i < n; i++){
        int m;
        cin >> m;
        for (int j = 0; j < m; j++){
            int edge;
            cin >> edge;
            adj[i].push_back(edge);
        }
    }
    bfs(adj, 1);
    int minDist = INT_MAX;
    bool canVisit = true;
    for (int i = 0; i < n; i++){
        if (i != 0){
            minDist = min(minDist, dist[i]);
        }
        if (!visited[i]) canVisit = false;
    }
    cout << (canVisit? "Y":"N") << "\n" << minDist+1;
}