#include <bits/stdc++.h>
#define ll long long
using namespace std;

map<ll, ll> ans;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    
}