#include <bits/stdc++.h>
using namespace std;
#define ll long long;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n, m;
    cin >> n >> m;
    vector<int> v(n);
    for (int i = 0; i < n; i++) cin >> v[i];
    sort(v.begin(), v.end());
    long long ans = 0;
    for(int i=0; i<n; i++) {
        ans += upper_bound(v.begin(), v.begin()+i, m-v[i]) - v.begin();
    }
    cout << ans << endl;
}