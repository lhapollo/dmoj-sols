#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    long long arr[n+n][n+n];
    for (int i = 0; i < 2*n; i++){
        for (int j = 0; j < 2*n; j++){
            cin >> arr[i][j];
        }
    }
    int end = (2*n);
    for (int i = 0 ; i < n; i++){
        cout << "layer: " << i + 1 << endl;
        //top row
        for (int j = i; j < end; j++){
            cout << arr[i][j] << " ";
        }
        cout << endl;
        //left col
        for (int j = i; j < end; j++){
            cout << arr[j][i] << " ";
        }
        cout << endl;
        for (int j = i; j < end; j++){
            cout << arr[end-1][j] << " ";    
        }
        cout << endl;
        // for (int j = i; j < end; j++){
            
        // }
        cout << endl;
        end--;
    }
    
}