#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    vector<pair<ll, ll>> vec;
    double speed = 0;
    for (int i = 0; i < n; i++){
        ll t, x;
        cin >> t >> x;
        vec.push_back(make_pair(t, x));
    }
    sort(vec.begin(), vec.end());
    ll prevTime = vec[0].first;
    ll prevPos = vec[0].second;
    for (int i = 1; i < vec.size(); i++){
        ll diff = vec[i].first - prevTime;
        prevTime = vec[i].first;
        ll dist = abs(vec[i].second - prevPos);
        prevPos = vec[i].second;
        speed = max(speed, dist*1.0/diff);
    }
    cout << fixed << setprecision(5) << speed << "\n";
}