#include <bits/stdc++.h>
using namespace std;
unordered_map<int, string> m; map<int,int> cnt;
int main(){
    int n;
    cin >> n;
    for (int i = 0; i < n; i++){
        string name;
        int num;
        cin >> name >> num;
        m[num] = name;
        cnt[num] = 0;
    }
    int d;
    cin >> d;
    for (int i = 0; i < d; i++){
        int num;
        cin >> num;
        cnt[num]++;
    }
    int ans = 0;
    int total = 0;
    for (auto i: cnt){
        if (i.second > total) {
            total = i.second;
            ans = i.first;
        }
    }
    cout << m[ans];
}