#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    int board = 0;
    for (int i = 0; i < n; i++){
        string word;
        cin >> word;
        if (word.length() <= 10) board++;
    }
    cout << board << "\n";
}