#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n, t;
    cin >> n >> t;
    vector<string> names(n);
    vector<int> vals(n);
    set<set<string>> ans;
    for (int i = 0; i < n; i++) cin >> names[i] >> vals[i];
    for (int i = 0; i < n; i++){
        for (int j = i+1; j < n; j++){
            for (int k = j+1; k < n; k++){
                if (t - vals[i] - vals[j] - vals[k] >= 0) {
                    set<string> com;
                    com.insert(names[i]);
                    com.insert(names[j]);
                    com.insert(names[k]);
                    ans.insert(com);
                }
            }
        }
    }
    for (auto i: ans){
        for (auto j: i){
            cout << j << " ";
        }
        cout << endl;
    }

}