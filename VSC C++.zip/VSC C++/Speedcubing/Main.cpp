#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    int n;
    cin >> n;
    double d1, d2, d3, d4, d5;
    double sum = 0;
    int place = 1;
    cin >> d1 >> d2 >> d3 >> d4 >> d5;
    sum = d1 + d2 + d3 + d4 + d5;
    sum -= max(max(max(d1,d2),max(d3,d4)),d5);
    sum -= min(min(min(d1,d2),min(d3,d4)),d5);
    for (int i = 1; i < n; i++){
        double c1,c2,c3,c4,c5;
        double csum = 0;
        cin >> c1 >> c2 >> c3 >> c4 >> c5;
        csum = c1 + c2 + c3 + c4 + c5;
        csum -= max(max(max(c1,c2),max(c3,c4)),c5);
        csum -= min(min(min(c1,c2),min(c3,c4)),c5);
        if (csum < sum) place++;
    }
    cout << place << "\n";
}