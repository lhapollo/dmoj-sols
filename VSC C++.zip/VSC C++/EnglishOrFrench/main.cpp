#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    int Tt = 0, Ss = 0;
    for (int i = 0; i <= n; i++){
        string s;
        getline(cin, s);
        for (int j = 0; j < s.length(); j++){
            if (s[j] == 't' || s[j] == 'T') Tt++;
            else if (s[j] == 's' || s[j] == 'S')Ss++;
        }
    }
    if (Tt > Ss) cout << "English" << "\n";
    else cout << "French" << "\n";
}