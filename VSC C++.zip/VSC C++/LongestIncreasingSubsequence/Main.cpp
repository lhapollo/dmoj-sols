#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    int dp[n];
    int arr[n];
    for (int i = 0; i < n; i++){
        cin >> arr[i];
    }
    int highest =0 ;
    for (int i = 0; i < n; i++){
        dp[i] = 1;
        for (int j = 0; j < i; j++){
            if (arr[j] < arr[i]){
                dp[i] = max(dp[i], dp[j]+1);
            }
        }
        highest = max(highest, dp[i]);
    }
    cout << highest << "\n";
}