#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);

    int n, q;
    
    cin >> n >> q;

    int arr[n];

    for (int i = 0; i < n; i++){
        cin >> arr[i];
    }

    for (int i = 0; i < q; i++){
        int query;
        cin >> query;
        if (query == 1){
            int start, end, v, k;
            cin >> start >> end >> v >> k;

            for (int j = start - 1; j < end; j++){
                if (arr[j] > k){
                    arr[j] -= v;
                }
            }
        }
        else if (query == 2){
            int start, end, k;
            cin >> start >> end >> k;
            long long sum = 0;
            for (int j = start -1; j < end; j++){
                if (arr[j] > k) sum += arr[j];
            }
            cout << sum << "\n";
        }
    }

}