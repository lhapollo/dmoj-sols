#include<bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int a = 0, b = 0;
    string deck[52];
    for (int i = 0; i < 52; i++){
        cin >> deck[i];
    }
    for (int i = 0; i < 52; i++){
        int counter = 0;
        if (deck[i] == "ace") counter = 4;
        else if (deck[i] == "king") counter = 3;
        else if (deck[i] == "queen") counter = 2;
        else if (deck[i] == "jack") counter = 1;

        if (i+counter < 52 && counter != 0){
            bool valid = true;
            for (int j = i+1; j <= i+counter; j++){
                if (deck[j] == "ace" or deck[j] == "king" or deck[j] == "queen" or deck[j] == "jack"){
                    valid = false;
                    break;
                }
            }
            if (valid){
                if (i % 2 == 0) {
                    a+= counter;
                    cout << "Player A scores " << counter << " point(s)." << "\n";
                }
                else {
                    b+= counter;
                    cout << "Player B scores " << counter << " point(s)." << "\n";
                }
            }
        }
        counter = 0;
    }
    cout << "Player A: " << a << " point(s)." << "\n";
    cout << "Player B: " << b << " point(s)." << "\n";
}