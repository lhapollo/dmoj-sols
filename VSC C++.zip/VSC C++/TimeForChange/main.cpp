#include <bits/stdc++.h>
using namespace std;
int findMin(vector<int> s, int target){
   int t[target+1];
   t[0] = 0;

   for (int i = 1; i <= target; i++){
       t[i] = INT_MAX;
       int result = INT_MAX;
       for (int c: s){
           if (i-c >= 0) result = t[i-c];

           if (result != INT_MAX) t[i] = min(t[i], result + 1);
       }
    }
    return t[target];
}

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    for (int i = 0; i < 2; i++){
        int target;
        cin >> target;
        int m; 
        cin >> m;
        vector<int> coins;
        for (int j = 0; j < m; j++){
            int cent;
            cin >> cent;
            coins.push_back(cent);
        }
        cout << findMin(coins, m) << "\n";
    }
}