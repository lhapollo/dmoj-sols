#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);

    string word;
    cin >> word;

    int count = 0;

    for (int i = 0; i < 5; i++){
        if (word[i] == 'a' || word[i] == 'e' || word[i] == 'i' || word[i] == 'o' || word[i] == 'u' || word[i] == 'y') count++;
    }
    cout << (count >= 2? "good": "bad") << "\n";
}