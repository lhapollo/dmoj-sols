#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    long long mod = 1000000007;
    long long a, b;
    cin >> a >> b;
    a %= mod;
    b %= mod;

    cout << (a * b) % mod << "\n";
}