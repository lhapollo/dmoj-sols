#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    for (int z = 0; z < 2; z++){
        int n;
        cin >> n;
        vector<int> v;
        for (int i = 0; i < n; i++) {
            int x;
            cin >> x;
            v.push_back(x);
        }
        int ans = 0;
        for (int i = n-1; i >= 1; i--){
            int p, q;
            p = find(v.begin(), v.end(), i)- v.begin();
            q = find(v.begin(), v.end(), i+1) - v.begin();
            if (p > q){
                v.erase(v.begin()+p);
                v.insert(v.begin(), i);
                ans += p;
            }
        }
        cout << ans << "\n";
    }
}