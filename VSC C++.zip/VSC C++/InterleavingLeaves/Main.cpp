#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio(true);
    cin.tie(0);
    int t;
    cin >> t;
    for (int i = 0; i < t; i++){
        int n;
        cin >> n;
        string one, two;
        cin >> one >> two;
        for (int j = n-1; j >= 0; j--){
            cout << two.at(j) << one.at(j);
        }
        cout << "\n";
    }
}