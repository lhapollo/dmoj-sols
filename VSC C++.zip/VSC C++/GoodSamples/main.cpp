#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    ll n, m, k;
    cin >> n >> m >> k;
    vector<ll> out; //output 
    for (ll i = 0; i < n; i++){
        ll rem = n-i-1; //after this, we have this number of items left to fill
        ll curr = min(k-rem,m); //how many new samples we create
        if (curr <= 0) break;
        ll val = curr;
        //choosing what value to go into vector
        if (curr > i){
            val = min(m,i+1);
            curr = val;
        }
        else val = out[i-curr]; //we want the same one curr places back
        out.push_back(val);
        k -= curr; //subtracts number of new samples made giving us how many more we need
    }
    if (k == 0 and (ll) out.size() == n){ //prints out vector if possible
        for (auto x: out) cout << x << " ";
        cout <<"\n";
    } else cout << -1 << "\n";

}