#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n, k;
    cin >> n >> k;
    vector<int> leaves;
    int minm = 1000001;
    for (int i = 0; i < n; i++){
        int s;
        cin >> s;
        leaves.push_back(s);
    }
    sort(leaves.begin(), leaves.end());
    for (int i = 0; i < k; i++){
        leaves[i] *= 2;
    }
    for (int i = 0; i < n; i++){
        minm = min(minm, leaves[i]);
    }
    cout << minm << "\n";
}