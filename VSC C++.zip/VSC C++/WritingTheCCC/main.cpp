#include <bits/stdc++.h>
using namespace std;
vector<string> order;
unordered_map<string, vector<int>> qs;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++){
        string s;
        cin >> s;
        order.push_back(s);
        qs[s] = {};
    }
    int q;
    cin >> q;
    for (int i = 1; i <=q; i++){
        string s;
        cin >> s;
        qs[s].push_back(i);
    }
    for (auto i: order){
        for (auto j: qs[i]){
            cout << j << "\n";
        }
    }
}