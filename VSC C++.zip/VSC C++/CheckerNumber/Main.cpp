#include <bits/stdc++.h>
using namespace std;
int search(vector<long long> v, unsigned int l, unsigned int r, long long x){
    if (r >= 1){
        int mid = l + (r-l) / 2;
        if (v[mid] == x) return mid;
        if (v[mid] > x) return search(v,l,mid-1,x);
        return search(v,mid+1,r,x);
    }
    return l;
}

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    long long t;
    cin >> t;
    vector<long long> squares;
    for (int i = 0; i <= 1000000000; i++){
        squares.push_back(i*i);
    }
    for (int i = 0 ; i < t; i++){
        long long n;
        cin >> n;
        long long root = -1;
        long long diff = 0;
        long long curr = n;
        while (root != -1){
            root = search(squares, 0, 1000000000, curr);
        }
        diff = n - (root*root);
        long long out =ceil(root / 9.0) + ceil(diff/9.0);
        if (out % 2 == 1) out++; 
        cout << out << "\n";
    }
}