#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    string one, two;
    int n;
    cin >> n;
    cin >> one >> two;
    bool canSit = false;
    for (int i =0 ; i < n; i++){
        if (one[i] == two[i] && one[i] == 'O'){
            canSit = true;
            break;
        }
    }
    cout << (canSit? ":)":":(") <<"\n";
}