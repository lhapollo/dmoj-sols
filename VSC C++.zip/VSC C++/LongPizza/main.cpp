#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
    int n;
    cin >> n;
    int x, y;
    cin >> x >> y;
    int r;
    cin >> r;
    ll diff[n];
    memset(diff, 0, sizeof(diff));
    for (int i = 0; i < r; i++){
        int a, b;
        cin >> a >> b;
        diff[a-1]++;
        diff[b]--;
    }
    ll arr[y];
    arr[0] = diff[0];
    for (int i =1; i < y; i++){
        arr[i] = arr[i-1] + diff[i];
    }
    ll psa[y];
    psa[0] = arr[0];
    for (int i = 1; i < y; i++){
        psa[i] = psa[i-1] + arr[i];
    }
    // for (auto i: psa) cout << i << endl;
    if (x == 1) cout << psa[y-1] << endl;
    else cout << psa[y-1] - psa[x-2] << endl;
}