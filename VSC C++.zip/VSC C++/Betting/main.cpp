#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int t;
    cin >> t;
    for (int i = 0; i < t; i++){
        long long a, b, c, d;
        cin >> a >> b >> c >> d;
        bool can = false;
        for (long long x = 0; x <= 100; x++){
            for (long long y = 0; y <= 100; y++){
                long long og = x + y;
                double g = (x*b*1.0)/a;
                double k = (y*d*1.0)/c;
                // g = floor(g*100+0.5)/100;
                // k = floor(k*100+0.5)/100;
                if (g > og && k > og){
                    can = true; 
                    break;
                }
            }
        }
        cout << (can? "YES":"NO") <<"\n";
    }
}