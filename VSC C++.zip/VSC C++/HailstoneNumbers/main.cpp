#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    long long n;
    cin >> n;
    long long counter = 0;
    while (n != 1){
        if (n % 2 == 0) n /= 2;
        else n = (n*3) +1;
        counter++;
    }
    cout << counter << "\n";
}