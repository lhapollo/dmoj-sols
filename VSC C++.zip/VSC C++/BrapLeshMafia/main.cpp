#include <bits/stdc++.h>
#define ll unsigned long long
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    ll n, k;
    ll total = 0;
    cin >> n >> k;
    for (int i = 0; i < n; i++){
        ll a, b;
        cin >> a >> b;
        total += a*b;
    }
    cout << total % k << "\n";
}