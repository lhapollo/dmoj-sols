#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    long long a, b, c;
    cin >> a >> b >> c;
    cout << max(max(a,b),c) - min(min(a,b),c);
}