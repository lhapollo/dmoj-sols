#include <bits/stdc++.h>
#define fast ios_base::sync_with_stdio(); cin.tie(0); 
#define len(s) s.length()
using namespace std;

unordered_set<string> out;

void solve(string s1, int i, string s2, int j, string curr){
    if (i == len(s1) and j == len(s2)) out.insert(curr);
    if (i < len(s1)) solve(s1, i+1, s2, j, curr + s1[i]);
    if (j < len(s2)) solve(s1, i, s2, j+1, curr + s2[j]);
}

int main(){
    fast;
    string a, b;
    cin >> a >> b;
    solve(a, 0, b, 0, "");
    for (string s: out){
        cout << s << "\n";
    }
}