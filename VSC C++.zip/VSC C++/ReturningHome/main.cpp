#include <bits/stdc++.h>
#define pb(n) push_back(n)
using namespace std;

vector<string> words;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    words.pb("HOME");
    string s ="";
    while (s.compare("SCHOOL") != 0){
        cin >> s;
        words.pb(s);
    }
    for (int i = words.size() -2; i >= 0; i--) {
        if (words[i] == "R") cout << "Turn LEFT ";
        else if (words[i] == "L") cout << "Turn RIGHT ";
        else if (words[i] == "HOME") cout << "into your HOME." << "\n";
        else cout << "onto " << words[i] << " street.\n";
    }
}