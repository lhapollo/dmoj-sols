#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define pb(n) push_back(n)

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    ll n;
    cin >> n;
    vector <ll> buttons;
    bool ok = true;
    for (ll i = 0; i < n; i++) {
        ll b; 
        cin >> b;
        buttons.pb(b);
    }
    for (ll i = 1; i < n; i++){
        if (buttons[i] == buttons[i-1]){
            ok = false;
            break;
        }
    }
    cout << (ok? "colourful!":"not colourful") << "\n";
}