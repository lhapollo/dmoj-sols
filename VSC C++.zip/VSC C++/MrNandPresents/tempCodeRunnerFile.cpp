for (auto i: out){
        if (i.second == match.at(i.first)){
            cout << i.first << " ";
        }
    }