#include <bits/stdc++.h>
using namespace std;

#define fast ios_base::sync_with_stdio(); cin.tie(0); cout.tie(0);

typedef long long ll;

int main(){
    fast
    int q;
    cin >> q; 
    deque<pair<ll, int>> out;
    unordered_map<ll, int> match;
    for (int i = 0; i < q; i++){
        char c;
        ll n;
        cin >> c >> n;
        if (c == 'F') {
            out.push_front(make_pair(n, i));
        }
        else if (c == 'E') {
            out.push_back(make_pair(n, i)); 
        }
        else if (c == 'R') match[n] = -1;
        match[n] = i;
    }
    for (auto i: out){
        if (i.second == match.at(i.first)){
            cout << i.first << "\n";
        }
    }
}