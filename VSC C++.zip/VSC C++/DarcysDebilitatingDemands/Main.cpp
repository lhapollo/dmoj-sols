#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int t;
    cin >> t;
    for (int i = 0; i < t; i++){
        long long n, a, b, c;
        cin >> n >> a >> b >> c;
        if (a + b + c < n) cout << -1 << "\n";
        else {
            if (c >= n) cout << "0 0 " << n <<"\n";
            else if (b + c >= n) cout << "0 " << n-c-b << " " << c << "\n";
        }
    }
}