#include <bits/stdc++.h>
using namespace std;

int convert(char c){
    if (c == 'S') return 0;
    else if (c == 'M') return 1;
    else if (c == 'L') return 2;
}

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int j, a;
    cin >> j >> a;
    int sizes[j];
    for (int i = 0; i < j; i++){
        char size;
        cin >> size;
        sizes[i] = convert(size);
    }
    int count = 0;
    for (int i = 0; i < a; i++){
        char size;
        int num;
        cin >> size >> num;
        int rep = convert(size);
        if (sizes[num-1] >= rep){
            sizes[num-1] = -1;
            count++;
        }
    }
    cout << count << "\n";
}