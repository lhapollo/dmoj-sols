#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    int street[n];
    int out = 0;
    int high = 0, low = 501;
    for (int i = 0; i < n; i++){
        cin >> street[i];
        out += street[i] + 1;
    }
    out += street[0];
    out += street[n-1];
    for (int i = 1; i < n; i++){
        out += max(street[i], street[i-1]);
    }
    cout << out << endl;
}