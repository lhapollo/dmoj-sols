#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int a, b, c, d, s;
    cin >> a >> b >> c >> d >> s;
    int countN = 0, countB = 0;
    int nStep = 0, bStep = 0;
    for (int i = 0; i < s; i++){
        if (countN % (a+b) < a) nStep++;
        else nStep--;
        countN++;
        if (countB % (c+d) < c) bStep++;
        else bStep--;
        countB++;
        //cout << nStep << " " << bStep << "\n";
    }
    if (nStep < bStep) cout << "Byron";
    else if (nStep > bStep) cout << "Nikky";
    else cout << "Tied";
}