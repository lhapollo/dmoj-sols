#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int i;
    cin >> i;
    long long n;
    cin >> n;
    long long arr[i+1];
    long long psa[i];
    long long j;
    cin >> j;
    memset(arr,0,sizeof(arr));
    int out = 0;
    for (int a = 0; a < j; a++){
        int l, r, k;
        cin >> l >> r >> k;
        l--;
        arr[l] += k;
        arr[r] -= k;
    }
    for (int a = 0; a < i; a++){
        if (a == 0) psa[a] = arr[a];
        else psa[a] = arr[a] + psa[a-1];

        if (psa[a] < n) out++;
    }
    cout << out <<"\n";
}