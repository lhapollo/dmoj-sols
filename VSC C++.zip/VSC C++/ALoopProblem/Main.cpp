#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio(true);
    cin.tie(0);

    long long l;
    long long r;

    cin >> l >> r;

    cout << ((l + r) * (r - l + 1))/2 << "\n";

}