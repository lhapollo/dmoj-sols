#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int d;
    cin >> d;
    for (int i = 1; i <= d; i++){
        int t;
        cin >> t;
        int sum = 0;
        for (int j = 0; j < t; j++){
            int x;
            cin >> x;
            sum += x;
        }
        if (t == 0) cout << "Weekend" << "\n";
        else cout << "Day " << i << ": " << sum << "\n";
    }
}