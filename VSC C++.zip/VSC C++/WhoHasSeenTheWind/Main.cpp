#include <bits/stdc++.h>
using namespace std;

int main(){
    int m, h;

    cin >> h >> m;

    int time = -1;

    for (int i = 1; i <= m; i++){
        if ((pow(i,4) * -6) + (h * pow(i,3)) + (2*pow(i,2)) + i <= 0){
            time = i;
            break;
        }
    }
    if (time != -1){
        cout << "The balloon first touches ground at hour:" << "\n" << time;
    } else{
        cout << "The balloon does not touch ground in the given time.";
    }
}