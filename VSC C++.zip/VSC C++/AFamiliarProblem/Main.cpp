#include <bits/stdc++.h>
using namespace std;

#define pb(n) push_back(n)
#define ll long long

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    ll m;
    cin >> n >> m;
    vector <ll> v;
    vector<ll> psa;
    ll psaSum = 0;
    for (int i = 0; i < n; i++){
        ll x;
        cin >> x;
        psaSum += x;
        v.pb(x);
        psa.pb(psaSum);
    }

    int l = 0, r = 0, len = 0;

    while (l <= r and r != n){
        if (l == 0){
            ll range = psa[r];
            if (range < m){
                if (r + 1 > len) len = r + 1;
                r++;
            }
            else if (range >= m ) {
                if (l == r) r++;
                else l++;
            }
        }
        else if (l != 0){
            ll range = psa[r] - psa[l-1];
            if (range < m){
                if (r-l+1 > len) len = r-l+1;
                r++;
            } else if (range >= m) l++;
        }
    }
    cout << len << "\n";
}