#include <bits/stdc++.h>
#define ll long long
using namespace std;

vector<int> energy;
vector<int> logs;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    for (int i = 0; i < n; i++){
        int e; 
        cin >> e;
        energy.push_back(e);
    }
    for (int i = 0; i < n; i++){
        int l;
        cin >> l;
        logs.push_back(l);
    }
    ll ans = 0;
    sort(energy.begin(), energy.end());
    sort(logs.begin(), logs.end(), greater<int>());
    for (int i = 0; i < n; i++){
        ans += energy[i] * logs[i];
    }
    cout << ans << "\n";
}