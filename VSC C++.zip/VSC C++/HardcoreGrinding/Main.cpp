#include <bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;
    vector <int> diff(10000000);
    for (int i = 0; i < n;i++){
        int l, r;
        cin >> l >> r;
        l--;
        r--;
        diff[l]++;
        diff[r]--;
    }
    vector<int> psa;
    psa[0] = diff[0];
    int maxm = 0;
    for (int i = 1; i < diff.size(); i++){
        psa[i] = psa[i-1] + diff[i];
        maxm = max(maxm, psa[i]);
    }
    cout << maxm << "\n";
}