#include <bits/stdc++.h>
using namespace std;

int main(){
    long long power = 0;
    long long temp = 0;
    while (power < 10){
        temp += (1 * (long long) pow(10, power));
        power++;
        cout << temp << endl;
    }
}