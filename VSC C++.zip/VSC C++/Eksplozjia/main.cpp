#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    string s1, s2;
    cin >> s1 >> s2;
    string ans ="";
    vector<bool> del(s1.length());
    stack<pair<char, int>> s;
    if (s2.length() == 1){
        char k = s2[0];
        for (int i = 0; i < s1.length(); i++){
            if (s1[i] == k) del[i] = true;
        }
    } else {
        for (int i = 0; i < s1.length(); i++){
            if (s1[i] == s2[0]) s.push(make_pair(s1[i], i));
            else if (!s.empty()){
                char prev = s.top().first;
                if (find(s2.begin(), s2.end(), prev+s1[i]) != s2.end()){
                    if (s1[i] == s2[s2.size()-1]) {
                        for (int i = 0; i < s2.length(); i++){
                            del[s.top().second] = true;
                            s.pop();
                        }
                    } else {
                        s.push(make_pair(s1[i], i));
                    }
                } else {
                    int size = s.size();
                    for (int i = 0; i < size; i++){
                        s.pop();
                    }
                }
            }
        }
    }
    for (int i = 0; i < del.size(); i++){
        if (!del[i]) ans += s1[i];
    }
    cout << (ans.length() == 0? "FRULA":ans) << "\n";
}