#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio(true);
    cin.tie(0);
    string line; 
    cin >> line;
    string s = "";
    string num = "";
    bool numfirst = false;
    for (int i = 0; i < line.size(); i++){
        if ((int)line[i] >= 65 && (int)line[i] <= 90){
            if (numfirst){
                cout << num <<"\n";
                num = "";
                numfirst = false;
            }
            cout << line[i];
        }
        if (line[i] == '+'){
            cout << " tighten ";
        } else if (line[i] == '-'){
            cout << " loosen ";
        } else if (line[i] >= 48 && line[i] <= 57){
            num += line[i];
            numfirst = true;
        }
    }
    cout << num << "\n";
}