#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int arr[2][2] = {{1,2}, {3,4}};
    int H = 0, V = 0;
    string s;
    cin >> s;
    for (int i = 0; i < s.length(); i++){
        if (s[i] == 'H') H++;
        else if (s[i] == 'V') V++;
    }
    H %= 2;
    V %= 2;
    if (H == 1){
        //swap horizontal
        int temp;
        temp = arr[0][0];
        arr[0][0] = arr[1][0];
        arr[1][0] = temp;
        temp = arr[0][1];
        arr[0][1] = arr[1][1];
        arr[1][1] = temp;
    }
    if (V == 1){
        //swap vertical
        int temp;
        temp = arr[0][0];
        arr[0][0] = arr[0][1];
        arr[0][1] = temp;
        temp = arr[1][0];
        arr[1][0] = arr[1][1];
        arr[1][1] = temp;
    }
    cout << arr[0][0] << " " << arr[0][1] << "\n" << arr[1][0] << " " << arr[1][1] << "\n";
}