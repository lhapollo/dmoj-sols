#include <bits/stdc++.h>
using namespace std;
#define ll long long

ll maxsub(ll arr[], int n){
    ll endMax = arr[0];
    ll endMin = arr[0];
    ll currMax = arr[0];

    for (int i = 1; i < n; i++){
        ll temp = max(max(arr[i], arr[i] * endMax), arr[i]*endMin);
        endMin = min(min(arr[i], arr[i] * endMax), arr[i]*endMin);
        endMax = temp;
        currMax = max(currMax, endMax);
    }
    return currMax;
}

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int t;
    cin >> t;
    for (int i = 0; i < t; i++){
        int n;
        cin >> n;
        ll arr[n];
        for (int j = 0; j < n; j++){
            cin >> arr[j];
        }
        cout << maxsub(arr, n) % 998244353 << endl;
    }
}