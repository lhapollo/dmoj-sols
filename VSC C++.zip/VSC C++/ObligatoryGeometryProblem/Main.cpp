#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n, q;
    cin >> n >> q;
    int arr[n];
    for (int i = 0; i < n; i++){
        arr[i] = 0;
    }
    for (int i = 0; i < q; i++){
        string setorget, shape;
        int index;
        cin >> setorget >> shape >> index;
        if (setorget[0] == 's'){
            if (shape[0] == 's') arr[index-1] = 1; //square 
            else if (shape[0] == 'c') arr[index-1] = 2; //circle
            else if (shape[0] == 't') arr[index-1] = 3; //triangle
        } else if (setorget[0] == 'g'){
            if (shape[0] == 's') cout << (arr[index-1] == 1? 1:0) << "\n";
            else if (shape[0] == 'c') cout << (arr[index-1] == 2? 1:0) << "\n";
            else if (shape[0] == 't') cout << (arr[index-1] == 3? 1:0) << "\n";
        }
    }
}