#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    string s = "";
    while (!s.compare("X") != 0){
        cin >> s;
        cout << isMonkey(s) << endl;
    }
}

bool isMonkey(string s){
    if (isA(s)) return true;
    for (int i = 1; i < s.length(); i++){
        if (s[i] == 'N' && isA(s.substr(0, i)) && isMonkey(s.substr(i+1))) return true;
    }
    return false;
}

bool isA(string s){
    if (s.compare("A") == 0) return true;
    else if (s[0] == 'B' && s[s.length()-1] == 'S' && isMonkey(s.substr(1, s.length()-2))) return true;
    else return false;
}