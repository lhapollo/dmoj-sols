#include <bits/stdc++.h>
#define macro "Hello, World!"
using namespace std;

int main(){
    cout << macro;
}