#include <bits/stdc++.h>
using namespace std;

vector<int> getCount(string s){
    vector<int> count = {0,0,0};
    for (char c: s){
        if (c == 'L') count[0]++;
        else if (c == 'M') count[1]++;
        else count[2]++;
    }
    return count;
}

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    string shelf;
    cin >> shelf;
    int l = getCount(shelf)[0], m = getCount(shelf)[1], s = getCount(shelf)[2];
    string firstL = shelf.substr(0,l);
    vector<int> sectL = getCount(firstL);
    string secondM = shelf.substr(l, m);
    vector<int> sectM = getCount(secondM);
    string thirdS = shelf.substr(l+m,s);
    vector<int> sectS = getCount(thirdS);

    int sinSwap = min(sectL[1], sectM[0]) + min(sectL[2], sectS[0]) + min(sectM[2],sectS[1]);

    int x = 0;
    
    if (sectL[1] < sectM[0]) x = sectM[0];
    else x = sectL[1];

    sectL[1] -= x;
    sectM[0] -= x;
    sectL[0] += x;
    sectM[1] += x;

    x = 0;
    
    if (sectL[2] < sectS[0]) x = sectL[2];
    else x = sectS[0];

    sectL[2] -= x;
    sectS[0] -= x;
    sectL[0] += x;
    sectS[2] += x;

    x = 0;
    
    if (sectM[2] < sectS[1]) x = sectM[2];
    else x = sectS[1];

    sectM[2] -= x;
    sectS[1] -= x;
    sectM[1] += x;
    sectS[2] += x;

    int douSwap = 2*(sectL[1] + sectL[2]);
}