#include <bits/stdc++.h>
using namespace std;

// A quick way to split strings separated via spaces.
vector<string> split(string s)
{
    vector<string> t;
    stringstream ss(s);
    string word;
    while (ss >> word) {
        t.push_back(word);
    }
    return t;
}

int main(){
    vector<string> years = {"Ox", "Tiger", "Rabbit", "Dragon", "Snake", "Horse", "Goat", "Monkey", "Rooster", "Dog", "Pig", "Rat"};
    ios_base::sync_with_stdio();
    unordered_map<string, pair<string, int>> um;
    um["Bessie"] = make_pair("Ox", 0);
    cin.tie(0);
    int n;
    cin >> n;
    for (int i = 0; i <= n; i++){
        string s;
        getline(cin, s);
    }
}