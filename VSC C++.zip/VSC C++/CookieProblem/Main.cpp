#include <bits/stdc++.h>
using namespace std;

int dp(int num, int array[], int memo[]){
    if (num <= 0) return 0;
    else if (memo[num] != 0) return memo[num];

    int x = max(dp(num-1, array, memo), dp(num-2, array, memo) + array[num-1]); 
    memo[num] = x;
    return x;
}
int main() {
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    int arr[n];
    int memo[n+1];
    memset(memo, 0, sizeof(memo));
    for (int i = 0; i < n; i++){
        cin >> arr[i];
    }
    memo[1] = arr[0];
    cout << dp(n, arr, memo) << "\n";
}