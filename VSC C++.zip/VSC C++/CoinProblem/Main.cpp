#include <bits/stdc++.h>
using namespace std;

vector<int> memo;

int dp(int v, int array[], int n){
    if (v == 0) return 0;
    else if (v < 0) return -1;

    if (memo[v] != -1) return memo[v];
    else{
        for (int i = 0; i < n; i++){
            if (memo[v] == 0) break;
            else memo[v] *= dp(v-array[i], array, n);
        }
    }
    return memo[v];
}

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n, s;
    cin >> n >> s;
    int coins[n];
    for (int i = 0; i < n; i++){
        cin >> coins[i];
    }    
    for (int i = 0; i <= s; i++){
        memo.push_back(-1);
    }
    cout << (dp(s, coins, n) == 0? "YES":"NO") << "\n";
}