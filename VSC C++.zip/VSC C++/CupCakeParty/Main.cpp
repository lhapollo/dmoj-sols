#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int r, s;
    cin >> r >> s;
    cout <<((r*8)+(s*3)) - 28 <<"\n";
}