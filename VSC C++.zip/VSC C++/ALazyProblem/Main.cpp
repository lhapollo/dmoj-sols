#include <bits/stdc++.h>
using namespace std;

int main(){
    int n, q;
    cin >> n >> q;
    long long element = 0;
    for (int i = 0; i < q; i++){
        long long query;
        cin >> query;
        if (query == 1){
            long long start, end;
            cin >> start >> end;
            cout << (end - start + 1) * element << "\n";
        }
        else if (query == 2){
            long long v;
            cin >> v;
            element += v;
        }
    }
}