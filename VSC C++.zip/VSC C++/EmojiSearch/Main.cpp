#include <bits/stdc++.h>
#define loop(i, a, b) for (int i = a; i < b; i++)
#define pb push_back

using namespace std;

int main(){
    typedef vector<string> vs;
    ios::sync_with_stdio(0);
    cin.tie(0);
    string s; 
    bool open = false;
    getline(cin, s);

    string emote = "";
    vs emotes;

    loop(i, 0, s.length()){
        if(s.at(i) == ':' && open == false){
            open = true;
        }
        else if (s.at(i) == ':' and open == true){
            open = false;
            emotes.pb(emote);
            emote.clear();
        }
        else if (open){
            emote += s.at(i);
            //cout << emote << "\n";
        }
    }

    for (string e: emotes) {
        cout << e << "\n";
    }

    return 0;
}