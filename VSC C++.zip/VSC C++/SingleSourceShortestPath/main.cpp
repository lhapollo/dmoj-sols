#include <bits/stdc++.h>
using namespace std;

priority_queue<pair<int, int>> q;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n, m;
    cin >> n >> m;
    vector<pair<int, int>> adj[n+1];
    int distances[n+1];
    bool processed[n+1];
    memset(processed, false, sizeof(processed));
    for (int i = 0; i < n; i++){
        int u, v, w;
        cin >> u >> v >> w;
        adj[u].push_back(make_pair(v,w));
    }
    for (int i = 1; i <= n; i++) distances[i] = INT_MAX;
    distances[1] = 0;
    q.push({0,1});
    while (!q.empty()){
        int a = q.top().second; q.pop();
        if (processed[a]) continue;
        processed[a] = true;
        for (auto u: adj[a]){
            int b = u.first, w = u.second;
            if (distances[a] + w < distances[b]){
                distances[b] = distances[a] + w;
                q.push({-distances[b], b});
            }
        }
    }
    cout << "done" << endl;
}