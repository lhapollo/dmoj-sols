#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    double n;
    cin >> n;
    int result = floor(sqrt(n*1.0)) - 5;
    if (result <= 0) cout << "impossible" <<"\n";
    else cout << result << "\n";
}