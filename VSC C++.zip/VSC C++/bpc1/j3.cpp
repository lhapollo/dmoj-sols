#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    vector<ll> arr;
    for (int i = 0; i < 2*n; i++){
        ll x;
        cin >> x;
        arr.push_back(x);
    }
    sort(arr.begin(), arr.end());
    ll ans = 0;
    for (int i = 1; i < 2*n; i+=2){
        ans += (arr[i]-arr[i-1]);
    }
    cout << ans << endl;
}