#include <bits/stdc++.h>
using namespace std;

int gcd(int a, int b){
    if (a == 0) return b;
    return gcd(b%a, a);
}

int main(){
    ios_base::sync_with_stdio(true);
    cin.tie(0);
    int n;
    cin >> n;
    int arr[n];
    for (int i = 0; i < n; i++){
        cin >> arr[i];
    }
    int ans = arr[0];
    for (int i = 1; i < n; i++){
        ans = gcd(arr[i], ans);
        if (ans == 1) break;
    }
    for (int i = 0; i < n; i++){
        cout << (arr[i] / ans) << " ";
    }
}