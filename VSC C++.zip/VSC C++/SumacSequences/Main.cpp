#include <bits/stdc++.h>
using namespace std;

int main(){
    int t1, t2;
    cin >> t1 >> t2;
    int curr = 10000;
    
    vector <int> sequences;
    sequences.push_back(t1);
    sequences.push_back(t2);
    while (curr >= 0){
        curr = t1 - t2;
        sequences.push_back(curr);
        t1 = t2;
        t2 = curr;
    }
    cout << sequences.size()-1;
}