#include <bits/stdc++.h>
using namespace std;

int main(){
    typedef string s;
    ios_base::sync_with_stdio(true);
    cin.tie(0);
    int n;
    cin >> n;

    for (int i = 0; i < n; i++){
        s move = "";
        cin >> move;
        if (move == "Rock") cout << "Paper\n";
        else if (move == "Paper") cout << "Scissors\n";
        else if (move == "Scissors") cout << "Rock\n";
        else if (move == "Fox") cout << "Foxen\n";
        else if (move == "Foxen") break;
    }

}