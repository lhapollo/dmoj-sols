#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    ll num;
    cin >> num;
    if (num == 0) {
        cout << "b" << "\n";
    } else{
        string out = "";
        vector<ll> nums;
        vector<bool> isA;
        ll sum = 0;
        ll a = 1;
        while (sum < num){
            sum += a;
            nums.push_back(a);
            a++;
            isA.push_back(true);
        }
        ll size = nums.size();
        ll subs = (size * (size+1)) / 2;
        a = 1;
        ll diff = subs - num;
        ll u = 0;
        ll count = 0;
        while(u < diff - a) {
            count++;
            u += a;
            a++;
        }
        diff -= u;
        for (ll i = 0; i < count; i++) {
            nums[i] = 0;
            isA[i] = 0;
        }
        ll index = count + 1;
        for (int i = 0 ; i < diff; i++){
            nums[index] --;
            isA[index] = 0;
            index += 2;
        }
        for (auto i: isA){
            if (i == 0) out += 'b';
            else out += 'a';
        }
        cout << out <<"\n";
    }  
}