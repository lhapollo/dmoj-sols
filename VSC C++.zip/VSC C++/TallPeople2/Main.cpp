#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    long long arr[n];
    for (int i = 0; i < n; i++){
        cin >> arr[i];
    }
    cout << 0 << " ";

    for (int i = 1; i < n; i++){
        int num = 0;
        for (int j = i-1; j >= 0; j--){
            if (arr[i] > arr[j]) num++;
            else if (arr[i] <= arr[j]) break;
        }
        cout << num << " ";
    }
}