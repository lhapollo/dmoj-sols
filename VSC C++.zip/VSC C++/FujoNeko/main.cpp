#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int r, c;
    cin >> r >> c;
    bool rows[r];
    bool cols[c];
    memset(rows, false, sizeof(rows));
    memset(cols, false, sizeof(cols));
    for (int i = 1; i <= r; i++) {
        for (int j = 1; j <= c; j++){
            char cr;
            cin >> cr;
            if (cr == 'X') {
                rows[i-1] = true;
                cols[j-1] = true;
            }
        }
    }
    int q;
    cin >> q;
    for (int i = 0; i < q; i++){
        int x, y;
        cin >> x >> y;
        if (rows[y-1] || cols[x-1]) cout << "Y" << "\n";
        else cout << "N" << "\n";
    }
}