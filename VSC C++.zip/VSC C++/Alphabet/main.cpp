#include <bits/stdc++.h>
using namespace std;

int dp[50];


int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    string s;
    memset(dp, 0, 50*sizeof(int));
    getline(cin, s);
    int n = s.length();
    for (int i = 0; i < n; i++){
        int best = 1;
        for (int j = 0; j < i; j++){
            if (s[j] < s[i] && dp[j] + 1 > best) best = 1 + dp[j];
        }
        dp[i] = best;
    }
    cout << 26 - dp[n-1] << endl;
}