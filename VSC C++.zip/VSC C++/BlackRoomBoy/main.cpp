#include <bits/stdc++.h>
using namespace std;

int main(){
    int t;
    cin >> t;
    
    for (int i = 0; i < t; i++){
        int a, b, c, d;
        cin >> a >> b >> c >> d;
        set<pair<int,int>> ans;
        ans.insert(make_pair(a+b, c+d));
        ans.insert(make_pair(a+c, b+d));
        ans.insert(make_pair(a+d, c+b));
        ans.insert(make_pair(b+c, a+d));
        ans.insert(make_pair(b+d, c+a));
        ans.insert(make_pair(c+d, a+b));
        cout << ans.size() << endl;
        for (auto j: ans){
            cout << j.first << " " << j.second << endl;
        }
    }
}