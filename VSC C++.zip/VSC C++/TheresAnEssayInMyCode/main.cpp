#include <bits/stdc++.h>
using namespace std;

const std::string WHITESPACE = " \n\r\t\f\v";
 
std::string ltrim(const std::string &s)
{
    size_t start = s.find_first_not_of(WHITESPACE);
    return (start == std::string::npos) ? "" : s.substr(start);
}
 
std::string rtrim(const std::string &s)
{
    size_t end = s.find_last_not_of(WHITESPACE);
    return (end == std::string::npos) ? "" : s.substr(0, end + 1);
}
 
std::string trim(const std::string &s) {
    return rtrim(ltrim(s));
}

int main(){
    for (int i = 0; i < 5; i++){
        string s;
        getline(cin, s);
        //iL -> // or ""
        bool iL = false;
        bool end = false;
        bool str = false;
        bool str2 = false;
        string ans ="";
        for (int j = 0; j < s.length(); j++){
            if (s[j] == '\"' && str) {
                str = false;
                ans += " ";
                continue;
            }
            else if (s[j] == '*' && s[j+1] == '/' && iL) {
                iL = false;
                ans += " ";
                continue;
            }
            else if (s[j] == '\'' && str2) {
                str2 = false;
                ans += " ";
                continue;
            }

            if (iL || end || str || str2){
                ans += s[j];
            }

            if (s[j] == '\"' && !end && !iL && !str2) {
                str = true;
            }
            else if (s[j] == '*' && s[j-1] == '/' && !end && !str && !str2){
                iL = true;
            } 
            else if (s[j] == '/' && s[j-1] == '/' && !str && !iL && !str2 ) end = true;
            else if (s[j] == '\'' && !str && !end && !iL) str2 = true;
            
        }
        cout << trim(ans) << "\n";
    }
}