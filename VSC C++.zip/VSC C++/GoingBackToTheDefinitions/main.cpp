#include <bits/stdc++.h>
using namespace std;

bool compare(string a, string b){
    return (a+b > b+a);
}

string method(string a[], int n){
    sort(a, a+n, compare);

    string ans = "";
    for (int i = 0; i < n; i++){
        ans += a[i];
    }

    return ans;
}

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    string arr[n];
    for (int i = 0; i < n; i++){
        cin >> arr[i];
    }
    cout << method(arr, n);
}