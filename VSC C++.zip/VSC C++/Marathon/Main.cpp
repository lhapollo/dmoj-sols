#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n, q;
    cin >> n >> q;
    vector <int> eps;
    for (int i = 0; i < n; i++) {
        int rating;
        cin >> rating;
        eps.push_back(rating);
    }
    vector<int> psa;
    psa.push_back(eps[0]);
    for (int i = 1; i < n; i++){
        psa.push_back(eps[i] + psa[i-1]);
    }
    for (int i = 0; i < q; i++){
        int l, r;
        cin >> l >> r;
        if (l == 1)cout << psa[n-1] - psa[r-1] <<"\n";
        else cout << psa[n-1] - (psa[r-1]-psa[l-2]) <<"\n";
    }
}