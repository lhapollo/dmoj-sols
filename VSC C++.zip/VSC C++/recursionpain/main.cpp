#include <bits/stdc++.h>
using namespace std;

int recursion(int n){
    if (n == 1) return 1;
    else return recursion(1) + recursion(n-1) + n-1;
}

int main(){
    cout << recursion(200) << endl;
}