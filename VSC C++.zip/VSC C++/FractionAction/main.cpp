#include <bits/stdc++.h>
#define fast ios_base::sync_with_stdio(); cin.tie(0); cout.tie(0);
using namespace std;

int gcd(int a, int b){
    if (b == 0) return a;
    return gcd(b, a%b);
}

int main(){
    fast
    int num, denom;
    cin >> num >> denom;
    //reduces to whole number
    if (num % denom == 0) cout << num / denom << "\n";
    //reduced fraction
    else if (num < denom){
        int f = gcd(num, denom);
        num /= f;
        denom /= f;
        cout << num << "/" << denom << "\n";   
    } else{
        int whole = num / denom;
        num %= denom;
        int f = gcd(num, denom);
        num /= f;
        denom /= f;
        cout << whole << " " << num << "/" << denom << "\n"; 
    }
}