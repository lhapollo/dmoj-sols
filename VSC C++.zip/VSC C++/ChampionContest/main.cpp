#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n , k;
    cin >> n >> k;
    vector<ll> v;
    vector<ll> copy;
    for (int i = 0; i < n; i++){
        ll x;
        cin >> x;
        v.push_back(x);
        copy.push_back(x);
    }
    int friends[n];
    memset(friends, 0, sizeof(friends));
    for (int i = 0; i < k; i++){
        int a, b;
        cin >> a >> b;
        if (v[a-1] > v[b-1]) friends[a-1]++;
        else friends[b-1]++;
    }
    sort(v.begin(), v.end());
    for (int i = 0; i < n; i++){
        int low = lower_bound(v.begin(), v.end(), copy[i]) - v.begin();
        cout << low-friends[i] << " ";
    }
}