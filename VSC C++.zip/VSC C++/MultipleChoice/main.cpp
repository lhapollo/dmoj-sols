#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    char student[n];
    char correct[n];
    int ans = 0;
    for (int i = 0; i < n; i++){
        cin >> student[i];
    }
    for (int i = 0; i < n; i++){
        cin >> correct[i];
    }
    for (int i = 0; i < n; i++){
        if (student[i] == correct[i]) ans++;
    }
    cout << ans << "\n";
}