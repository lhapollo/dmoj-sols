#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n, m;
    cin >> n >> m;
    double x = 0.0, y = 0.0;
    for (int i = 0; i < n; i++){
        double a, b;
        cin >> a >> b;
        x += a;
        y += b;
    }
    bool can = true;
    for (int i = 0; i < m; i++){
        double a, b;
        cin >> a >> b;
        set<double> sx;
        set<double> sy;
        if ((y/x) == (b/a)){
            can = false;
            break;
        }
        
    }
    cout << (can? "yes":"no") << "\n";
}
