#include <bits/stdc++.h>
#define ll long long
using namespace std;

vector<ll> sum, cnt;
ll n, c;

//number of points between a and b
ll point (ll a, ll b){
    if (a <= b) {
        ll d = sum[b] - (a == 0? 0 : sum[a-1]);
        return d;
    } else {
        ll d = sum[b] + (sum[c-1] - sum[a-1]);
        return d;
    }
}

int main(){
    cin >> n >> c;
    //number of points on circle means sum and cnt are size 'c'
    sum.resize(c);
    cnt.resize(c);
    for (ll i = 0; i < n; i++){
        ll x;
        cin >> x;
        cnt[x]++; //the number of points at point (x) on circle
    }
    sum[0] = cnt[0];
    //sum is psa and sum[i] is the sum of points from 0 to i
    for (ll i = 1; i < c; i++) sum[i] = sum[i-1] + cnt[i];

    //total ways of picking three points on circle
    ll ans = n * (n-1) * (n-2) / 6; 

    //process of subtracting how many triplets that DON'T meet the conditions 
    for (ll i = 0; i < c; i++){
        ll opp = (i+c/2)%c;
        ll tot = point(i+1, opp);
        ans-= cnt[i] * tot * (tot-1)/2;
        ans-= cnt[i] * (cnt[i]-1)/2*tot;
        ans-= cnt[i] * (cnt[i]-1)*(cnt[i]-2)/6;
    }
    //adding back any we may have miscounted
    if (c % 2 == 0){
        for (ll i = 0; i < c/2; i++){
            ll opp = i + c/2;
            ans += cnt[i] * (cnt[i]-1)/2*cnt[opp];
            ans += cnt[i] * cnt[opp] * (cnt[opp] - 1) / 2;
        }
    }
    cout << ans << "\n";
}