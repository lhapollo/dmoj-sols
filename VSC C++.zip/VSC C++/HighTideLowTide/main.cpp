#include <bits/stdc++.h> 
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    vector<int> v;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        v.push_back(x);
    }
    sort(v.begin(), v.end());
    vector<int> lo, hi;
    if (n % 2 == 0){
        for (int i = 0; i < n/2; i++){
            lo.push_back(v[i]);
            hi.push_back(v[i+(n/2)]);
        }
    } else {
        for (int i = 0; i <= n/2; i++){
            lo.push_back(v[i]);
        }
        for (int i = 1; i <= n/2; i++){
            hi.push_back(v[i+(n/2)]);
        }
    }
    reverse(lo.begin(), lo.end());
    for (int i = 0; i < n/2; i++){
        cout << lo[i] << " " << hi[i] << " ";
    }
    if (n % 2 == 1) cout << lo[n/2];
}