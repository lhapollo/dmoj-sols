#include <bits/stdc++.h>
#define pb(n) push_back(n)
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    vector<int> m;
    for (int i = 0; i < n; i++){
        int x;
        cin >> x;
        m.pb(x);
    }
    sort(m.begin(), m.end());
    if (n % 2 == 0){
        double d = (1.0*(m[n/2] + m[(n/2)-1]) / 2.0);
        d = round(d);
        cout << d << "\n";
    } else {
        cout << m[(n-1)/2] << "\n";
    }

}