#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int l, w, s;
    cin >> l >> w >> s;
    cout << ceil(l/s) * ceil (w/s) << "\n";
}