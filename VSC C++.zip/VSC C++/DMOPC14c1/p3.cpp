#include <bits/stdc++.h>
#define fast ios_base::sync_with_stdio(); cin.tie(0); cout.tie(0);
#define in(n) cin >> n;
using namespace std;

int main(){
    fast;
    int i;
    in(i);
    double sum = 0.0;
    for (int a = 0; a < i; a++){
        double x;
        in(x);
        sum += x;
    }
    int s;
    in(s);
    for (int a = i+1; a <= i+s; a++){
        double y;
        in(y);
        sum += y;
        cout << fixed << showpoint;
        cout << setprecision(3);
        cout << (sum*1.0)/a << "\n";
    }
}