#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int count = 0;
    int s, e;
    cin >> s >> e;
    for (int i = s; i <= e; i++){
        int factors = 0;
        for (int j = 1; j <= sqrt(i); j++){
            if (i % j == 0) {
                if (i / j == j) factors++;
                else factors += 2;
            }
        }
        if (factors == 4) count++;
    }
    cout << "The number of RSA numbers between " << s <<" and " << e << " is " << count <<"\n";
}