#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int t;
    cin >> t;
    for (int i = 0; i < t; i++){
        int n, m;
        cin >> n >> m;
        int diff[n+1];
        memset(diff, 0, sizeof(diff));
        for (int j = 0; j < m; j++){
            int l, r, v;
            cin >> l >> r >> v;
            l--;
            diff[l] += v;
            diff[l+r] -= v;
        }
        ll max = -1;
        int ans = -1;
        ll curr;
        ll prev;
        for (int j = 0; j < n; j++)
        {
            if (j == 0) {
                curr = diff[j];
                prev = diff[j];
                if (curr >= max)
                {
                    max = curr;
                    ans = j+1;
                }
            }
            else {
                curr = diff[j] + prev;
                if (curr >= max)
                {
                    max = curr;
                    ans = j + 1;
                }
                prev = curr;
            }
        }
        cout << ans << "\n";
    }
}