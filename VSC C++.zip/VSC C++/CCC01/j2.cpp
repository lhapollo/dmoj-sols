#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int x, m;
    cin >> x >> m;
    bool t = false;
    for (int i = 1; i < m; i++){
        if ((x*i) % m == 1) {
            t = true;
            cout << i << "\n";
            break;
        }
    }
    if (!t) cout << "No such integer exists." << "\n";
}