#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int t;
    cin >> t;
    for (int i = 0; i < t; i++) {
        int n;
        cin >> n;
        if (n <= 30 and n >= 0) cout << 38 << "\n";
        else if (n > 30 and n <= 50) cout << 55 <<"\n";
        else if (n > 50 and n <= 100) cout << 73 << "\n";
        else if (n > 100){
            int additional = n - 100;
            cout << 73 + (24 * (ceil(additional / 50.0))) << "\n";
        }
    }
}