#include <bits/stdc++.h>
#define add(n) push_back(n);
#define ll long long
using namespace std;

vector<ll> psa;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    ll arr[n];
    for (int i = 0; i < n; i++) cin >> arr[i];
    psa.add(arr[0]);
    for (int i = 1; i < n; i++) psa.add(arr[i] + psa[i-1]);
    ll q;
    cin >> q;
    for (int i = 0; i < q; i++){
        int s, e;
        cin >> s >> e;
        if (s == 0) cout << psa[e] << "\n";
        else cout << psa[e] - psa[s-1] << "\n";
    }
}