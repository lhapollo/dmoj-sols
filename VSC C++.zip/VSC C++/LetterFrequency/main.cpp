#include <bits/stdc++.h>
using namespace std;

pair<pair<int, int>, char> query;
vector<vector<int>> psa;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    string s;
    getline(cin, s);
}