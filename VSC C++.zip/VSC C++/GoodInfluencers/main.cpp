#include <bits/stdc++.h>
#define ll long long
using namespace std;
const ll mx = 3e6+9;

int n;
int nrm = 0, on = 1, pay = 2;
int dp[mx][5];
vector<int> v[mx];
string p;
vector<int> cost;

int solve(int a, int prev, int state){
    int &ret = dp[a][state];
    if (ret != -1) return ret; //returning memoized state
    if(p[a] == 'Y' or state == on){
        //try paying them
        int out = cost[a];
        for (auto x: v[a]) {
            if (x == prev) continue;
            int cur = solve(x, a, on);
            if (cur == INT_MAX){
                out = INT_MAX;
                break;
            }
            else out += cur;
        }

        //don't pay them
        if (state != pay){
            int out1 = 0;
            for (auto x: v[a]){
                
            }
        }
    }

}