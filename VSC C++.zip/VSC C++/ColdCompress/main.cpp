#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    for (int i = 0; i < n; i++){
        string s;
        cin >> s;
        char curr = s[0];
        int count = 1;
        for (int j = 1; j < s.length(); j++){
            if (s[j] != s[j-1]){
                cout << count << " " << curr << " ";
                curr = s[j];
                count = 1;
            } else count++;
        }
        cout << count << " " << curr <<"\n";
    }
}