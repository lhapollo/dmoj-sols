#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    string s;
    getline(cin,s);
    int upper = 0, lower = 0;
    for (int i = 0 ; i < s.length(); i++){
        int value = (int) s[i];
        if (value >= 65 && value <= 90) upper++;
        else if (value >= 97 && value <= 122) lower++;
    }
    if (lower == upper) cout << s << "\n";
    else if (lower > upper){
        for (int i = 0; i < s.length(); i++){
            cout << putchar(tolower(s[i]));
        }
    }
    else if (upper > lower){
        for (int i = 0; i < s.length(); i++){
            cout << putchar(toupper(s[i]));
        }
    }
}