#include <bits/stdc++.h>
using namespace std;

int main(){
    int s;
    cin >> s;
    int l = floor(sqrt(s));
    cout << "The largest square has side length " << l << "." << endl;
}