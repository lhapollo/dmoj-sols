#include <bits/stdc++.h>
using namespace std;

long long factorial(long long num){
    long long prod = 1;
    for (long long i = num; num > 0; i--){
        prod *= i;
    }
    return prod;
}

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    long long num;
    cin >> num;
    cout << factorial(num) << endl;
}