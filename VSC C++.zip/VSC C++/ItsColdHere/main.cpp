#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    string s = "";
    string ans = "";
    int coldest = 201;
    do {
        int temp;
        cin >> s >> temp;
        if (temp < coldest) {
            coldest = temp;
            ans = s;
        }
    } while (s.compare("Waterloo") != 0);
    cout << ans << endl;
}