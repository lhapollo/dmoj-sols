#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n, m;
    cin >> n >> m;
    long long sum = 0;
    long long arr[n+1][m+1];
    long long dp[n+1][m+1];
    for (int i = 0; i <= n; i++){
        arr[i][0] = 0;
        dp[i][0] = INFINITY;
    }
    for (int i = 0; i <=m; i++){
        arr[0][i] = 0;
        dp[0][i] = INFINITY;
    }
    for (int i = 1; i <= n; i++){
        for (int j = 1; j <= m; j++){
            cin >> arr[i][j];
        }
    }
    dp[1][1] = arr[1][1];
    for (int i = 1; i <= n; i++){
        for (int j = 1; j <= m; j++){
            if (i == 1 && j == 1) continue;
            else{
                dp[i][j] = min(dp[i][j-1],dp[i-1][j]) + arr[i][j];
            }
        }
    }
    cout << dp[n][m];
}