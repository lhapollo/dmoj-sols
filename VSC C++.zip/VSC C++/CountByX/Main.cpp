#include <bits/stdc++.h>
using namespace std;

int main(){
    int one, two, three;
    int diff;

    scanf("%d",&one);
    scanf("%d",&two);
    scanf("%d",&three);

    diff = three - two;

    printf("%d", diff + three);
    cout << "\n";
    printf("%d", diff + diff + three);
    cout << "\n";
    printf("%d", diff + diff + diff + three);
    cout <<"\n";
}