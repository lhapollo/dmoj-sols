#include <bits/stdc++.h>
using namespace std;

//a -> 97
//z -> 122

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    string s, code;
    cin >> s >> code;
    int count = 0; 
    int n = s.length();
    int m = code.length();
    // //declare a character (char), then cast char to int for ASCII
    // char c = 'f';
    // int k = (int) c;
    if (s.find(code) != string::npos){
        cout << 0 << "\n";
        cout << s << "\n"; 
    } else{
        for (int i = 0; i <= 25; i++){
        count = i;
        string newS = "";
        for (int j = 0; j < s.length(); j++){
            char c = s[j];
            int cVal = (int) c;
            cVal--;
            if (cVal < 97) cVal = 122;
            char newChar = (char) cVal;
            newS += newChar;
        }
        s = "";
        s = newS;
        if (s.find(code) != string::npos) break;
    }
    count++;
    cout << count << "\n";
    cout << s << "\n";
    }
}