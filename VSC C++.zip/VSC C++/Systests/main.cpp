#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
    ios_base::sync_with_stdio(true);
    cin.tie(0);
    int b;
    cin >> b;
    vector<pair<ll, ll>> v;
    vector<ll> values;
    ll points = 0;
    for (int i = 0; i < b; i++){
        ll f, e, p;
        cin >> f >> e >> p;
        v.push_back(make_pair(f, e));
        values.push_back(p);
        points += p;
    }
    int f;
    cin >> f;
    vector<ll> fails;
    for (int i = 0; i < f; i++){
        ll t;
        cin >> t;
        fails.push_back(t);
    }
    sort(fails.begin(), fails.end());
    for (int i = 0; i < b; i++){
        auto ub = upper_bound(fails.begin(), fails.end(), v[i].first) - fails.begin();
        auto lb = lower_bound(fails.begin(), fails.end(), v[i].second) - fails.begin();
        if (fails[lb-1] == v[i].second)lb--;
        if (ub != lb) points -= values[i];
    }
    cout << points << endl;
}