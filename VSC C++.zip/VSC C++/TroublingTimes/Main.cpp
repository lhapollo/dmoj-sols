#include <bits/stdc++.h>

using namespace std;

int main(){
    int n, d;
    int j = 10001; 
    cin >> n >> d;
    int intervals[n];
    for (int i = 0; i < n; i++){
        cin >> intervals[i];
    }

    for (int interval: intervals){
        if (abs(d) % interval == 0){
            if (abs(d) / interval < j){
                j = abs(d) / interval;
            }
        }
    }

    if (j == 10001){
        cout << "This is not the best time for a trip." << endl;
    }
    else{
        cout << j << endl;
    }

    return 0;
}