#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio(true);
    cin.tie(0);
    int a, b;
    cin >> a >> b;
    int ans = 0;
    for (int i = ceil(pow(a, 1.0/6)); pow(i, 6) <= b; i++){
        ans++;
    }
    cout << ans << endl;
}