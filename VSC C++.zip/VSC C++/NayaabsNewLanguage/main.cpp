#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    string str;
    bool valid = true;
    bool vowel = false;
    cin >> str;
    for (int i = 0; i < str.length(); i++){
        if (str[i] == 'a' or str[i] == 'e' or str[i] == 'i' or str[i] == 'o' or str[i] == 'u'){
            if (!vowel) vowel = true;
            else{
                valid = false;
                break;
            }
        } else {
            if (i == 0) continue;
            else if (vowel) vowel = false;
            else{
                valid = false;
                break;
            }
        }
    }
    cout << (valid? "yes":"no") <<"\n";
}