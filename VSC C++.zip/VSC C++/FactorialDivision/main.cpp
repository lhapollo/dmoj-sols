#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    ll n, m;
    ll out = 1;
    cin >> n >> m;
    for (ll i = n; i > m; i--){
        out *= i;
    }
    cout << out << "\n";
}