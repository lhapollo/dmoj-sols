#include <bits/stdc++.h>
using namespace std;

list<char> b1(int n, list<char> v){
    for (int i = 0; i < n; i++){
        char t = v.front();
        v.push_back(t);
        v.pop_front();
    }
    return v;
}

list<char> b2(int n, list<char> v){
    for (int i = 0; i < n; i++){
        char t = v.back();
        v.push_front(t);
        v.pop_back();
    }
    return v;
}

list<char> b3(int n, vector<char> v){
    for (int i = 0; i < n; i++){
        char temp = v[1];
        v[1] = v[0];
        v[0] = temp;
    }
    list<char> g (v.begin(), v.end());
    return g;
}

int main(){
    ios::sync_with_stdio();
    cin.tie(0);
    list<char> v = {'A', 'B', 'C', 'D', 'E'};
    int b = -1, n = -1;
    while (b != 4){
        cin >> b >> n;
        if (b == 1) v = b1(n, v);
        else if (b == 2) v = b2(n, v);
        else if (b == 3){
            vector<char> v2 (v.begin(), v.end());
            v = b3(n, v2);
        }
    }
    for (auto i: v) cout << i << " ";
}