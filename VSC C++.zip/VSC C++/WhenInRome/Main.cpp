#include <bits/stdc++.h>
using namespace std;

string numToRoman(int num){
    string thousands[] = {"","M","MM","MMM"};
    string hundreds[] = {"","C","CC","CCC","CD","D","DC","DCC","DCCC","CM"};
    string tens[] = { "",  "X",  "XX",  "XXX",  "XL","L", "LX", "LXX", "LXXX", "XC" };
    string ones[] = { "",  "I",  "II",  "III",  "IV","V", "VI", "VII", "VIII", "IX" };

    string thou = thousands[num/1000];
    string hund = hundreds[(num%1000)/100];
    string ten = tens[(num%100)/10];
    string one = ones[num%10];

    string ans = thou + hund + ten + one;
    return ans;
}

int RomanToInt(string roman){
    unordered_map<char,int> index;
    index.emplace('I',1);
    index.emplace('V',5);
    index.emplace('X',10);
    index.emplace('L',50);
    index.emplace('C',100);
    index.emplace('D',500);
    index.emplace('M',1000);
    int result = 0;
    for (int i = 0; i < roman.length(); i++){
        char c = roman[i];
        if (i > 0 && index.at(c) > index.at(roman[i-1])) result += index.at(c) - 2*index.at(roman[i-1]);
        else result += index.at(c);
    }
    return result;
}

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int t;
    cin >> t;
    for (int i = 0; i < t; i++){
        string equation;
        cin >> equation;
        string first, second;
        int index = equation.find("+");
        first = equation.substr(0,index);
        second = equation.substr(index+1);
        second.erase(second.end()-1);
        int num1 = RomanToInt(first), num2 = RomanToInt(second);
        int out = num1 + num2;
        string sum = (out > 1000? "CONCORDIA CUM VERITATE": numToRoman(out));
        cout << first << "+" << second << "=" << sum << "\n";
    }
}
