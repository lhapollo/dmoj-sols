#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio();
    cin.tie(0);
    string s;
    while (s.compare("0") != 0){
        getline(cin, s);
        if (s == "0") break;
        stack<string> stk;
        for (int i = s.length()-1; i >= 0; i--){
            if (s[i] == '+' || s[i] == '-'){
                string o1 = stk.top();
                stk.pop();
                string o2 = stk.top();
                stk.pop();
                string temp = o1 + " " + o2 + " " + s[i];
                stk.push(temp); 
            }
            else if (s[i] == ' ') continue;
            else {
                stk.push(string(1, s[i]));
            }
        }
        cout << stk.top() << endl;
    }
}