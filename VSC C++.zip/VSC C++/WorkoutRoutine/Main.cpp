#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    cout.tie(0);
    long long n, k;
    long long total;
    cin >> n >> k;
    if (n*1000000000 < k) cout << -1;
    else{
        for (long long i = 1; i < n; i++){
            cout << i << " ";
            total += i;
        }
        long val = 0;
        for (long long i = n-1; i <= 1000000000;){
            if ((total + i) % k == 0) {
                val = i-1;
                break;
            }

        }
        cout << val;
    }

}