#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    long long arr[n];
    long long ideal = 0;
    vector<int> indices;
    for (int i = 0; i < n; i++){
        cin >> arr[i];
        ideal += abs(arr[i]);
    }
    int sign = 1;
    for (int i = n-1; i >= 0; i--){
        if (sign*arr[i] < 0){
            indices.push_back(i+1);
            sign *= -1;
        }
    }
    cout << ideal <<"\n";
    for (int i = indices.size()-1; i >= 0; i--){
        cout << indices[i] <<" ";
    }
}