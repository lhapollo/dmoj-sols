#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio(true);
    cin.tie(0);
    int T;
    cin >> T;
    for (int t = 0; t < T; t++){
        int N;
        cin >> N;
        unordered_map<string, vector<pair<int, int>>> um;
        for (int i = 0; i < N; i++){
            int M;
            cin >> M;
            for (int j = 0; j < M; j++){
                string name;
                cin >> name;
                int p, q;
                cin >> p >> q;
                um[name].push_back(make_pair(p, q));
            }
        }
        for (auto& i:um){
            sort(i.second.begin(), i.second.end());
        }
        int K;
        cin >> K;
        int ans = 0;
        for (int i = 0; i < K; i++){
            string prod;
            int quantity;
            cin >> prod >> quantity;
            for (auto i: um[prod]){
                if (quantity == 0) break;
                else {
                    int amt = min(quantity, i.second);
                    ans += amt * i.first;
                    quantity -= amt;
                }
            }
        }
        cout << ans << endl;
    }
}