#include <bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;
    vector<int> v;
    for (int i = 0; i < n; i++){
        int in;
        cin >> in;
        v.push_back(in);
    } 
    for (int i = 0; i < n; i++){
        vector<int> start;
        vector<int> end;
        int max1 = -1;
        for (int j = 0; j < i-v[i]; j++){
            start.push_back(v[j]);
            if (start.size() > 0){
                max1 = max(max1,v[j]);
            }
        } 
        int max2 = -1;
        for (int j = i+1; j < n; j++){
            end.push_back(v[j]);
            if (end.size() > 0){
                max2 = max(max2, v[j]);
            }
        }
        cout << max(max1,max2) << "\n";
    }
}