#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    vector<long long> sums;
    ll ans = 0;
    long long maxNum = 0;
    for (int i = 0; i < n-1; i++){
        long long k;
        cin >> k;
        sums.push_back(k);
        maxNum = max(maxNum, k);
    }
    for (int i = 1; i <= maxNum; i++){
        ll start = i;
        bool can = true;
        for (ll s: sums){
            start = s - start;
            if (start <= 0) {
                can = false;
                break;
            }
        }
        if (can) ans++;
    }
    cout << ans << endl;
}