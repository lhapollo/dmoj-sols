#include <bits/stdc++.h>
using namespace std;



void addScore(){

}

int main(){
    int n;
    cin >> n;
    unordered_map<int, vector<int> > graph;
    int scores[n];
    bool visited[n];

    for (int i = 1; i <= n; i++){
    }
}