#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio(true);
    cin.tie(0);
    int b, c;
    cin >> b >> c;
    cout << 0 << "\n";
    int temp = 0;
    for (int i = 0; i < 4; i ++){
        temp = pow(temp, 2) + b * temp + c;
        cout << temp << "\n";
    }
}