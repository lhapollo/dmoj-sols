#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n, m, k;
    cin >> n >> m >> k;
    int amt = n;
    for (int i = 0; i < m; i++){
        int vol;
        cin >> vol;
        amt -= vol;
        if (amt < 0) {
            cout << "Impossible." << "\n";
            break;
        } else if (amt <= k){
            cout << i + 1 <<"\n";
            amt = n;
        }
    }
}