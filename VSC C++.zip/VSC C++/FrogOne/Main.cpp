#include <bits/stdc++.h>
using namespace std;
int dp(int start, vector<int> array, int store[]){
    if (store[start] != INT_MAX) return store[start];
    if (start == 0 || start == 1) return store[start];
    int amt = min((dp(start-2, array, store) + abs(array[start] - array[start-2])), (dp(start-1, array, store) + (abs(array[start] - array[start-1]))));
    store[start] = amt;
    return amt;
}
int main(){
    int n;
    cin >> n;
    int memo[n+1];
    vector<int> list;
    for (int i: memo){
        i = INT_MAX;
    }
    memo[0] = 0;
    memo[1] = 0;

    list.push_back(INT_MAX);

    for (int i = 0; i < n; i++){
        int input;
        cin >> input;
        list.push_back(input);
    }
    cout << dp(2, list, memo);
}