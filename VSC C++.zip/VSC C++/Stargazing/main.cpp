#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    int x[n];
    int y[n];

    x[0] = 0;
    y[0] = 0;

    for (int i = 1; i <= n-1; i++){
        int index, xdiff, ydiff;
        cin >> index >> xdiff >> ydiff;
        x[i] = x[index-1] + xdiff;
        y[i] = y[index-1] + ydiff;
    }
    set<pair<int, int>> planets;
    for (int i = 0; i < n; i++){
        planets.insert(make_pair(x[i],y[i]));
    }
    cout << planets.size() << "\n";
}