#include <bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;
    vector<char> v;
    int most = 0;
    for (int i = 0; i < n; i++){
        char x;
        cin >> x;
        v.push_back(x);
        if (x == '1') most = i;
    }
    char a = '0';
    int ans = 0;
    for (int i = most; i >= 0; i--){
        if (a != v[i]){
            if (a == '0') a = '1';
            else a = '0';
            ans++;
        }
    }
    cout << ans << endl;
    return 0;
}