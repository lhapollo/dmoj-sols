#include <bits/stdc++.h>
using namespace std;

bool isPrime(int num){
    for (int i = 2; i <= sqrt(num); i++){
        if (num % i ==0) return false;
    }
    return true;
}

int main(){
    ios_base::sync_with_stdio();
    cin.tie();
    int t; 
    cin >> t;
    for (int i = 0; i < t; i++){
        int x;
        cin >> x;
        x *= 2;
        for (int j = 3; j < x/2; j+=2){
            if (isPrime(j) && isPrime(x-j)){
                cout << j << " " << x-j << "\n";
                break;
            }
        }
    }
}