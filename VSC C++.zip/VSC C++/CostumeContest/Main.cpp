#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);

    int n;

    cin >> n;

    int arr[n];
    int score = 0;
    int max = 0;

    for (int i = 0; i < n; i++){
        cin >> arr[i];
        score += arr[i];
        if (arr[i] > max) max = arr[i];
    }

    cout << score - max << "\n";
}