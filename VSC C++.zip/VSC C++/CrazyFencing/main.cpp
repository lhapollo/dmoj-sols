#include <bits/stdc++.h>
#define pb(n) push_back(n)
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    vector<int> h;
    vector<int> w;
    for (int i = 0; i <= n; i++){
        int a;
        cin >> a;
        h.pb(a);
    }
    for (int i = 0; i < n; i++){
        int b;
        cin >> b;
        w.pb(b);
    }
    double ans = 0.0;
    for (int i = 1; i < h.size(); i++){
        ans += (h[i] + h[i-1]) * w[i-1]; 
    }
    cout << fixed << ans/2.0 << "\n";
}