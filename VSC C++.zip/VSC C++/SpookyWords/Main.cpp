#include <bits/stdc++.h>

using namespace std;
vector<string> sortWords(int len, vector<string> bank, vector<string> result){
    set<string> sortedWords;
    for (string s: bank){
        if (s.length() == len){
            sortedWords.insert(s);
        }
    }
    for (string s: sortedWords){
        result.push_back(s);
    }
    return result;
}

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n, q;
    cin >> n >> q;
    vector<string> words;
    vector<string> out;
    set<int> lengths;
    for (int i = 0; i < n; i++){
        string s;
        cin >> s;
        words.push_back(s);
        lengths.insert(s.length());
    }
    for (int i: lengths){
        out = sortWords(i, words, out);
    }
    for (int i = 0; i < q; i++){
        int index;
        cin >> index;
        cout << out.at(index-1) << "\n";
    }
}