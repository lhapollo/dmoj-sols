#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio(true);
    cin.tie(0);
    int n;
    cin >> n;
    int stars = 0;
    for (int i = 0; i < n; i++){
        int points, fouls;
        cin >> points >> fouls;
        if ((points * 5) - (fouls * 3) > 40) stars++;
    }
    cout << stars;
    if (stars == n) cout <<"+"<<"\n";
    
}