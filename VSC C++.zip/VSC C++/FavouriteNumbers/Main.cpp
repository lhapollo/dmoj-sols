#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    vector<long long> nums;
    nums.push_back(1);
    long long c2 = 0, c3 = 0;
    for(int i = 0; i < n; i++){
        long long next = min(nums[c2]*2, nums[c3]*3);
        nums.push_back(next);
        if (next == 2*nums[c2]) c2++;
        if (next == 3*nums[c3]) c3++;
    }
    cout << nums[n-1] << "\n";
}