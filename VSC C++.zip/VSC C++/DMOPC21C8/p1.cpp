#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    bool can = true;
    int n, m;
    cin >> n >> m;
    vector<int> in;
    vector<int> out;
    for (int i = 0; i < n; i++){
        int t;
        cin >> t;
        in.push_back(t);
    }
    sort(in.begin(), in.end());
    bool used[n];
    memset(used, false, sizeof(used));
    for (int i = 0; i < n-1; i++){
        if (used[i]) continue;
        else{
            out.push_back(in[i]);
            used[i] = true;
            for (int j = i+1; j < n; j++){
                if (in[j] + in[i] >= m && !used[j]) {
                used[j] = true;
                out.push_back(in[j]);
                break;
                }
            }
        }
    }
    // for (int i = 0; i < n/2; i++){
    //     out.push_back(in[i]);
    //     out.push_back(in[n-i-1]);
    // }
    if (n % 2 == 1) out.push_back(in[n-1]);
    for (int i = 1; i < n; i++){
        ll sum = out[i] + out[i-1];
        if (sum < m){
            can = false; 
            break;
        }
    }
    if (can) {
        for (int i : out) cout << i << " ";
    } else cout << -1 << "\n";
    return 0;
}