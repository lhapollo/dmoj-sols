for (int i = 1; i < n; i++){
    //     ll sum = out[i] + out[i-1];
    //     if (sum < m){
    //         can = false; 
    //         break;
    //     }
    // }