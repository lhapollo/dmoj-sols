#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    vector<char> bits;
    //GH = 1, HG = 0
    for (int i = 0; i < n/2; i++) {
        char one, two;
        cin >> one >> two;
        if (one == 'G' && two == 'H') bits.push_back('1');
        else if (one == 'H' && two == 'G') bits.push_back('0');
    }
    char a = '0';
    int ans = 0;
    for (int i = bits.size()-1; i >= 0; i--){
        if (a != bits[i]){
            if (a == '0') a = '1';
            else a = '0';
            ans++;
        }
    }
    cout << ans << endl;
}