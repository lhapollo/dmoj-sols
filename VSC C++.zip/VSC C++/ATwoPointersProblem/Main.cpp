#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    long long n;
    long long m;
    cin >> n >> m;
    long long sum = 0;
    vector <long long> v;
    for (long long i = 0; i < n; i++){
        long long x;
        cin >> x;
        v.push_back(x);
    }
    long long len = n+1;
    long long s = 0, e = 0;
    for (int i = e; i < v.size(); i++){
        sum += v.at(i);
        while (sum >= m){
            len = min(len, i-s+1);
            sum -= v.at(s);
            s++;
        }
    }
    cout << (len == n+1? -1: len) << "\n";
}