#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int q;
    cin >> q;
    int machines[3];
    cin >> machines[0];
    cin >> machines[1];
    cin >> machines[2];
    int counter = 0;

    while (q >= 0){
        if (q == 0) break;
        for (int i = 0; i < 3; i++){
            if (q == 0) break;
            machines[i]++;
            counter++;
            q--;
            if (i == 0 && machines[i] % 35 == 0) q+= 30;
            else if (i == 1 && machines[i] % 100 == 0) q += 60;
            else if (i == 2 && machines[i] % 10 == 0) q += 9;
        }
    }
    cout << "Martha plays " << counter << " times before going broke." << "\n";
}