#include <bits/stdc++.h>
using namespace std;
const int MAX = 255;
int memo[MAX][MAX][MAX];

int dp(int n, int k, int m){ //takes in n, k, and a minimum of m
    int& val = memo[n][k][m]; //val is a reference to memo[n][k][m]
    if (val >= 0) return val; //checks if val is memoized

    //base cases 
    if (k == 1) return val = (m > n) ? 0: 1;
    if (n == k) return val = (m == 1) ? 1 : 0;

    val = 0; 
    for (int i = m; i <= n - k + 1; i++){
        val += dp(n - i, k - 1, i);
    }
    return val;
}

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n, k;
    cin >> n >> k;
    memset(memo, -1, sizeof(memo));
    int ans = dp(n, k, 1);
    cout << ans << "\n";
}
