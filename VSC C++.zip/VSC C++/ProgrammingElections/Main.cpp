#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int t;
    cin >> t;
    for (int i = 0; i < t; i++){
        int maxM = 0, maxF = 0;
        string mName = "", fName = "";
        int n;
        cin >> n;
        for (int j = 0; j < n; j++){
            int vote;
            char gender;
            string name;
            cin >> name >> gender >> vote;
            if (gender == 'M'){
                if (vote > maxM){
                    maxM = vote;
                    mName = name;
                }
            } else if (gender == 'F'){
                if (vote > maxF){
                    maxF = vote;
                    fName = name;
                }
            }
        }
        cout << fName << " " << mName << "\n";
    }
}
