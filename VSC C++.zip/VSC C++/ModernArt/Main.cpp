#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    cout.tie(0);
    int m, n, k;
    cin >> m >> n >> k;
    int rows[m] = {};
    int cols[n] = {};
    long long sumR = 0, sumC = 0;
    for (int i = 0; i < k; i++){
        char rc;
        long long index;
        cin >> rc >> index;
        if (rc == 'R') rows[index-1]++;
        else cols[index-1] ++;
    }
    for (int i = 0; i < n; i++) sumC += cols[i]%2;
    for (int i = 0; i < m; i++) sumR += rows[i]%2;

    cout << (n*sumR) + (m*sumC ) - (2*sumR*sumC) << "\n";
}