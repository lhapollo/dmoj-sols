#include<bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int t;
    cin >> t;
    for (int i = 0; i < t; i++){
        vector<double> v;
        double n;
        cin >> n;
        double sum = 0;
        int candy = 0;
        for (int j = 0; j < n; j++){
            double num;
            cin >> num;
            v.push_back(num);
            sum += num;
        }
        double avg = (sum/n) - 50.0;
        //cout << avg << endl;
        for(double d: v){
            if (d - avg >= 50.0) candy++;
        }
        cout << candy << "\n";
    }
}