#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    string in;
    cin >> in;
    string zero, one; //name represents starting character
    for (int i = 0; i < n; i++){
        zero += ""+(i%2);
        one += ""+(i+1)%2;
        cout << zero << " " << one << endl;
    }
}