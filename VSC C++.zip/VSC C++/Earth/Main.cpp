#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    long long x,y;
    long long x1, x2, y1, y2;
    cin >> x >> y;
    cin >> x1 >> y1 >> x2 >> y2;

    if (x > x1 && x < x2 && y > y1 && y < y2) cout << "Yes";
    else cout << "No";
}