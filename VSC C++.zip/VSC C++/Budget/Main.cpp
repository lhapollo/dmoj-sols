#include <iostream>

using namespace std;

int main(){
    int n, b;
    cin >> n >> b;
    int total = 0;
    
    for (int i = 0; i < n; i++){
        int amt;
        cin >> amt;
        total += amt;
    }

    if (total > b){
        printf("The budget will balance itself");
    } else {
        cout << b - total << endl;
    }

    return 0;
}