#include <bits/stdc++.h>
using namespace std;

long long dp(int pos, long long arr[], long long memo[]){
    if (pos <= 0) return 0;
    if (pos == 1) return max(arr[1], (long long) 0);
    if (memo[pos] != -1) return memo[pos];

    memo[pos] = max(dp(pos-1, arr, memo), dp(pos-2, arr, memo) + arr[pos]);
    return memo[pos];
}

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    long long arr[n+1];
    long long memo[n+1];
    for (int i = 0; i <= n; i++) memo[i] = -1;
    memo[0] = 0;
    arr[0] = 0;
    for (int i = 1; i <= n; i++){
        cin >> arr[i];
    }
    cout << max(dp(n, arr, memo),(long long) 0) << "\n";
}