#include <bits/stdc++.h>
using namespace std;

int sum(int f){
    unordered_set<int> out;
    int ans = 0;
    if (sqrt(f) * sqrt(f) == f) {
        ans += sqrt(f);
        out.insert(sqrt(f));
    }
    for (int i = 1; i < sqrt(f); i++){
        if (f % i == 0) {
            int a = i;
            int b = f/i;
            if (!out.count(a)) ans += a;
            out.insert(a);
            if (b != f) {
                if (!out.count(b)) ans += b;
                out.insert(b);
            }
        }
    }
    return ans;
}

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n;
    cin >> n;
    for (int i = 0; i < n; i++){
        int x;
        cin >> x;
        if (sum(x) < x) cout << x << " is a deficient number." << "\n";
        else if (sum(x) == x) cout << x << " is a perfect number." << "\n";
        else cout << x << " is an abundant number." << "\n";
    }
}