#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n, k, q;
    cin >> n >> k >> q;
    vector<ll> v(n), psa(n+1);
    unordered_map<ll, vector<int>> indices;
    for (int i = 0; i < n; i++){
        cin >> v[i]; indices[v[i]].push_back(i+1);
    }
    psa[0] = 0;
    for (int i = 1; i <= n; i++) psa[i] = psa[i-1] + v[i-1];
    for (int i = 0; i < q; i++){
        int a, b, x, y;
        cin >> a >> b >> x >> y;
        ll sum = psa[y] - psa[x-1];
        bool aBad, bBad;
        if (lower_bound(indices[a].begin(), indices[a].end(), x) == upper_bound(indices[a].begin(), indices[a].end(), y)){
            if (find(indices[a].begin(), indices[a].end(),x) != indices[a].end()){
                aBad = false;
            } else aBad = true;
        }
        else aBad = false;
        if (lower_bound(indices[b].begin(), indices[b].end(), x) == upper_bound(indices[b].begin(), indices[b].end(), y)){
            if (find(indices[b].begin(), indices[b].end(),x) != indices[b].end()){
                bBad = false;
            } else bBad = true;
        }
        else bBad = false;
        cout << ((sum > k && !bBad && !aBad)? "Yes":"No")<< endl;
    }
}