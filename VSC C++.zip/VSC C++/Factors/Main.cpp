#include <iostream>
#include <stdio.h>
#include <math.h>

using namespace std;

int main(){
    long long a, b;
    long long factors = 0;

    cin >> a >> b;

    long long sum = ((a+b) * (b-a+1))/2;

    for (int i = 1; i < sqrt(sum); i++){
        if (sum % i == 0){
            factors += 2;
        }
    }

    if (sum / sqrt(sum) == sqrt(sum)){
        factors++;
    }

    cout << factors << endl;

}