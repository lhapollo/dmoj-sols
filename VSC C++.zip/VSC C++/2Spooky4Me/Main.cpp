#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
    int n;
    ll l, s;
    cin >> n >> l >> s; 
    vector<pair<ll, ll>> v;
    for (int i = 0; i < n; i++){
        ll start, end, val;
        cin >> start >> end >> val;
        v.push_back(make_pair(start, val));
        v.push_back(make_pair(end+1, -val));
    }
    sort(v.begin(), v.end());
    ll out = l, spookiness = 0, prevIndex = 0;
    bool subtract = false;
    for (auto i: v) {
        if (subtract){
            out -= (i.first - prevIndex);
            subtract = false;
        } else {
            spookiness += i.second;
            if (spookiness >= s){
                subtract = true;
                prevIndex = i.first;
            }
        }
    }
    cout << out << "\n";
}