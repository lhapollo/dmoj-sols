#include <bits/stdc++.h>
#define ll long long
using namespace std;

int vals[10000001];

void sieve(int n){
    bool prime[n+1];
    memset(prime, true, sizeof(prime));
    memset(vals, 0, sizeof(vals));
    for (int p = 2; p * p <= n; p++){
        if (prime[p]){
            for (int i = p*p; i <= n; i+=p){
                prime[i] = false;
                vals[i]++;
            }
        }
    }
}

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    sieve(10000000);
    int t;
    cin >> t;
    for (int i = 0; i < t; i++){
        ll a, b, k;
        cin >> a >> b >> k;
        ll ans = 0;
        for (ll j = a; j <= b; j++){
            if (vals[j] == k) ans++;
        }
        cout << ans << endl;
    }
}