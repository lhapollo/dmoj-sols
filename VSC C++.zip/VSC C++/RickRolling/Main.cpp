#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    //49QQWXcdgww -> length 11
    string link;
    string perm = "49QQWXcdgww";
    cin >> link;
    bool troll = false;
    if (link.size() < 11) troll = true;
    else {
        for (int i = 0; i < link.size() - 11 ; i += 11){
            string sub = link.substr(i,11);
            sub = sort (sub.begin(),sub.end());
            if (sub.compare(perm) == 0) {
                troll = true;
                break;
            }
        }
    } 
    cout << (!troll? "rickroll":"not a rickroll");
}