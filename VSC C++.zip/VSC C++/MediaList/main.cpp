#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    int n, q;
    cin >> n >> q;
    vector<set<string>> v(n);
    for (int i = 0; i < q; i++){
        int type, num;
        cin >> type >> num;
        string name;
        cin >> name;
        if (type == 1) cout << (v[num-1].find(name) != v[num-1].end()? 1: 0) << "\n";
        else if (type == 2) v[num-1].insert(name);
    }
}