#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    bool bw = false, f = false, t = false, lp = false, cr = false;
    string s;
    cin >> s;
    for (int i = 0; i < s.length(); i++){
        if (s[i] == 'B') bw = true;
        else if (s[i] == 'F') f = true;
        else if (s[i] == 'T') t = true;
        else if (s[i] == 'L') lp = true;
        else if (s[i] == 'C') cr = true;
    }

    if (bw && f && t && lp && cr) cout << "NO MISSING PARTS" << "\n";
    else{
        cout << (!bw? "B\n":"");
        cout << (!f? "F\n":"");
        cout << (!t? "T\n":"");
        cout << (!lp? "L\n":"");
        cout << (!cr? "C\n":""); 
    }
}