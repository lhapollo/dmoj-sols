#include <bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio();
    cin.tie(0);
    cout.tie(0);
    int n, k;
    cin >> n >> k;
    int arr[k];
    //bool visited[k];
    int starts[n];
    for (int i = 0; i < k; i++){
        cin >> arr[i];
    }
    for (int i = 0 ; i < n; i++){
        cin >> starts[i];
    }
    int sum;
    int output = 0;
    for (int i = 0; i < n; i++){
        //for (auto b: visited) b = false;
        sum = 0;
        if (starts[i] != -1){
            sum = arr[starts[i]-1];
            output = max(output, sum);
            //visited[starts[i]-1] = true;
            //cout << "sum = " << sum << endl;
        }
        for (int j = i+2; j < n; j++){
            if (starts[j] == -1) continue;
            else if (starts[j] != starts[i]){
                output = max(output, sum+arr[starts[j]-1]);
                //cout << "greatest sum: "<< output << endl;
            }
        }
    }
    cout << output << "\n";
}