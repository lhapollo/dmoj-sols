package AssigningPartners;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        HashMap<String, String> partners = new HashMap<String, String>();
        int n = Integer.parseInt(br.readLine());
        String[] a = br.readLine().split(" "), b = br.readLine().split(" ");
        for (int i = 0; i < n; i++){
            partners.put(a[i],b[i]);
        }
        boolean can = true;
        for (String s: partners.keySet()){
            if (!partners.get(partners.get(s)).equals(s) || partners.get(s).equals(s)){
                can = false;
                break;
            }
        }
        System.out.println(can? "good":"bad");
    }
}
