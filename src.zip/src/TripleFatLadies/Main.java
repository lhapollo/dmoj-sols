package TripleFatLadies;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(br.readLine());
        long num = 0;
        ArrayList<Long> nums = new ArrayList<Long>();

        for (int i = 0; i < t; i++){
            String number = br.readLine();
            num = Long.parseLong(number);
            if (num <= 192){
                num = 192;
            }
            if (number.length() >= 3) {
                int hundredsToOne = Integer.parseInt(number.substring(number.length() - 3));
                if (hundredsToOne <= 192){
                    num += (192 - hundredsToOne);
                }
                else if (hundredsToOne > 192 && hundredsToOne <= 442){
                    num += (442 - hundredsToOne);
                } else if (hundredsToOne > 442 && hundredsToOne <= 692){
                    num += (692 - hundredsToOne);
                } else if (hundredsToOne > 692 && hundredsToOne <= 942){
                    num += (942 - hundredsToOne);
                } else if (hundredsToOne > 943){
                    num += (1192 - hundredsToOne);
                }
            }

            nums.add(num);
        }
        for (long n: nums){
            System.out.println(n);
        }
    }
}
