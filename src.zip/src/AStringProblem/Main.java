package AStringProblem;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        HashMap<Character, Integer> counts = new HashMap<>();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s = br.readLine();
        for (int i = 0; i < s.length(); i++) counts.put(s.charAt(i), counts.getOrDefault(s.charAt(i), 0) + 1);
        ArrayList<Integer> list = new ArrayList<Integer>(counts.values());
        Collections.sort(list, Collections.reverseOrder());
        int sum = 0;
        for (int i = 0; i < list.size(); i++){
            if (i == 0 || i == 1) continue;
            else sum += list.get(i);
        }
        System.out.println(sum);
    }
}
