package Boolean;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] sentence = br.readLine().split(" ");
        int not = 0;
        for (String word : sentence){
            if (word.equals("not")){
                not++;
            }
        }
        if (not % 2 == 0 && sentence[sentence.length -1].equals("True")){
            System.out.println("True");
        } else if (not % 2 == 0 && sentence[sentence.length - 1].equals("False")){
            System.out.println("False");
        } else if (not % 2 == 1 && sentence[sentence.length - 1].equals("True")){
            System.out.println("False");
        } else if (not % 2 == 1 && sentence[sentence.length - 1].equals("False")){
            System.out.println("True");
        }
    }
}
