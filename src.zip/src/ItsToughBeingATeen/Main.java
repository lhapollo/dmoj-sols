package ItsToughBeingATeen;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        //adjacency list (each list has the nodes u need to complete before doing this one)
        ArrayList<Integer>[] adj = new ArrayList[7];
        for (int i = 0; i < 7; i++){
            adj[i] = new ArrayList<Integer>();
        }
        //the constants
        adj[0].add(2);
        adj[3].add(1);
        adj[3].add(3);
        adj[4].add(3);
        adj[6].add(1);
        //boolean array
        boolean[] visited = new boolean[7];
        int before = -1,  after = -1;
        while (before != 0 && after != 0){
            before = Integer.parseInt(br.readLine());
            after = Integer.parseInt(br.readLine());
            if (before == 0 && after == 0) break;
            adj[after-1].add(before);
        }
        boolean valid = true;
        ArrayList<Integer> order = new ArrayList<>();
        TreeSet<Integer> set = new TreeSet<>();
        while (valid){
            boolean empty = false;
            for (int i = 0; i < 7; i++){
                if (adj[i].size() == 0 && !visited[i]) {
                    empty = true;
                    set.add(i+1);
                }
            }
            if (!empty){
                valid = false;
                break;
            } else {
                int temp = set.first();
                visited[temp-1] = true;
                set.remove(temp);
                order.add(temp);
                for (int j = 0; j < 7; j++){
                    if (adj[j].contains(temp)) adj[j].remove(Integer.valueOf(temp));
                }
            }
        }
        if (order.size() == 7){
            for (int i: order) System.out.print(i + " ");
        } else System.out.println("Cannot complete these tasks. Going to bed.");
    }
}
