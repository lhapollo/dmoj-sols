package HarpTuning;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        //getting input
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String line = br.readLine();

        String letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; //generating all the letters in alphabet
        String digits = "0123456789"; //generating all digits in alphabet

        String strings = "";
        String num = "";
        boolean currentlyNumber = false; //checks if the current character is a letter

        for (int i = 0; i < line.length(); i++){
            //if the current character is a letter
            if (letters.contains(""+line.charAt(i))){
                strings += line.charAt(i);
                if (currentlyNumber){ //checks if there is a transition between number and letter
                    System.out.println(num);
                    currentlyNumber = false;
                    num = num.replace(num, ""); //clears num
                }
            } else if (line.charAt(i) == '+' || line.charAt(i) == '-'){ //if character is an operator
                System.out.print(strings); //displaying instructions as we go
                System.out.print(line.charAt(i) == '+' ? " tighten " : " loosen ");
                strings = strings.replace(strings, ""); //clears the strings variable
            } else if (digits.contains(""+line.charAt(i))){
                num += line.charAt(i);
                currentlyNumber = true;
            }
        }
        System.out.println(num); //prints out last num at the end.
    }
}
