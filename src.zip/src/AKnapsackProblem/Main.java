package AKnapsackProblem;

import java.io.*;

public class Main {
    public static int maxWeight(int N, int W , int[] values, int[] weights) {
        int[][] matrix = new int[N+1][W+1];
        //base cases
        for (int i = 0; i < W + 1; i++){
            matrix[0][i] = 0;
        }
        for (int i = 0 ; i < N + 1; i++){
            matrix[i][0] = 0;
        }
        //i = item, j = capacity
        for (int i = 1; i <= N; i++){
            for (int j = 1; j <= W; j++){
                //looks at the value NOT considering item i
                int valWOCurr = matrix[i-1][j];

                //initializes variable for value WITH consideration of item i
                int valWCurr = 0;

                int weightCurr = weights[i-1]; //finds weight of item i

                //if the capacity of the bag is bigger than the current weight
                if (j >= weightCurr) {
                    //value with consideration of item i is AT LEAST item i's weight.
                    valWCurr = values[i-1];

                    //finds remaining capacity
                    int remainC = j - weightCurr;

                    //adds max value of items with the remaining capacity left (without considering item i)
                    valWCurr += matrix[i-1][remainC];
                }

                //sets max value in (i,j)
                matrix[i][j] = Math.max(valWOCurr, valWCurr);
            }
        }
        return matrix[N][W];
    }
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), w = Integer.parseInt(line[1]);

        //declaring arrays for both weights and values respectively
        int[] weights = new int[n];
        int[] values = new int[n];

        //input
        for (int i = 0; i < n; i++){
            line = br.readLine().split(" ");
            weights[i] = Integer.parseInt(line[0]);
            values[i] = Integer.parseInt(line[1]);
        }
        System.out.println(maxWeight(n,w,values,weights));
    }
}
