package AKnapsackProblem;

import java.io.*;
import java.util.*;

public class BlindMain {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        //how many pieces, and weight of ur knapsack
        int n = Integer.parseInt(line[0]), w = Integer.parseInt(line[1]);
        int[][] mat = new int[n + 1][w + 1];

        int[] values = new int[n], weights = new int[n];
        for (int i = 0; i < n; i++){
            line = br.readLine().split(" ");
            weights[i] = Integer.parseInt(line[0]);
            values[i] = Integer.parseInt(line[1]);
        }

        //base cases
        for (int i = 0; i <= n; i++){
            mat[i][0] = 0;
        }
        for (int i = 0; i <= w; i++){
            mat[0][i] = 0;
        }

        for (int item = 1; item <= n; item++){
            for (int capacity = 1; capacity <= w; capacity++){
                int withNoCur = mat[item-1][capacity];
                int withCur = 0;
                int weight = weights[item-1];

                if (capacity >= weight){
                    withCur = values[item-1];
                    int leftOver = capacity - weight;
                    withCur += mat[item-1][leftOver];
                }
                mat[item][capacity] = Math.max(withNoCur,withCur);
            }
        }
        System.out.println(mat[n][w]);
    }
}
