package HomeworkQuestions;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        TreeSet<Long> values = new TreeSet<Long>();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        String[] arr = br.readLine().split(" ");
        for (int i = 0; i < n*n; i++) values.add(Long.parseLong(arr[i]));
        ArrayList<Long> iterate = new ArrayList<Long>(values);
        ArrayList<Long> ans = new ArrayList<Long>();
        int start = 0;
        for (int i = 0; i < Math.ceil((n*1.0)/2); i++){
            if (iterate.get(start) % 2 == 1) {
                i--;
                start++;
            }
            else {
                ans.add(iterate.get(start)/2);
                start += 2;
            }
        }
        start = iterate.size()-1;
        for (int i = 0; i < Math.floor((n*1.0)/2); i++){
            if (iterate.get(start) % 2 == 1) {
                i--;
                start--;
            }
            else {
                ans.add(iterate.get(start)/2);
                start -= 2;
            }
        }
        for (int i = 0; i < n; i++){
            System.out.print(ans.get(i) + (i == n-1? "\n":" "));
        }
    }
}
