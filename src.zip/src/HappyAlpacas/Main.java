package HappyAlpacas;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), x = Integer.parseInt(line[1]);
        int[] arr = new int[n];
        if ((n-x) % 2 == 1) System.out.println(-1);
        else {
            int index = 0;
            for (int i = 0; i < (n-x)/2; i++){
                arr[index]++;
                index += 2;
            }
            System.out.println(Arrays.toString(arr).replace("[","").replace("]", "").replace(",", ""));
        }
    }
}
