package MediaList;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), q = Integer.parseInt(line[1]);
        List<HashSet<String>> sets = new ArrayList<HashSet<String>>();
        for (int i = 0; i < n; i++) {
            HashSet<String> t = new HashSet<>();
            sets.add(t);
        }
        for (int i = 0; i < q; i++){
            line = br.readLine().split(" ");
            int qNum = Integer.parseInt(line[0]);
            int ind = Integer.parseInt(line[1]);
            String name = line[2];
            if (qNum == 1) System.out.println(sets.get(ind-1).contains(name)? 1: 0);
            else sets.get(ind-1).add(name);
        }
    }
}
