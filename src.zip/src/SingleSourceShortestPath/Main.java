package SingleSourceShortestPath;

import java.io.*;

public class Main {
    //returns index with smallest distance from 0 that hasn't been processed yet
    public static int minDist(boolean[] b, int[] d){
        int min = Integer.MAX_VALUE, index = -1;
        for (int i = 0; i < d.length; i++){
            if (!b[i] && d[i] <= min){
                min = d[i];
                index = i;
            }
        }
        return index;
    }

    //outputs distances from 0 (if it's max value, there's no way to get there, so we output -1)
    public static void output(int dist[], int x){
        for (int i = 0; i < x; i++){
            System.out.println(dist[i] == Integer.MAX_VALUE? -1: dist[i]);
        }
    }

    //takes in the graph, and the starting source, which will be 0)
    public static void dijkstra(int graph[][], int src){
        //distance array and processed boolean array
        int dist[] = new int[graph.length];
        boolean b[] = new boolean[graph.length];

        //initializing arrays
        for (int i = 0; i < dist.length; i++){
            dist[i] = Integer.MAX_VALUE;
            b[i] = false;
        }

        //the distance from the source node to itself is always 0.
        dist[0] = 0;

        for (int i = 0; i < dist.length; i++){
            int u = minDist(b, dist); //finds the next index to be processed (smallest distance from source node)
            b[u] = true; //we don't have to process it again
            //loop through all other nodes
            for (int y = 0; y < dist.length; y++){
                //checks conditions to see if node is fit, and then updates distance between nodes
                if (!b[y] && graph[u][y] != 0 && dist[u] != Integer.MAX_VALUE && dist[u]+graph[u][y] < dist[y]){
                    dist[y] = dist[u] + graph[u][y];
                }
            }
        }
        output(dist, dist.length); //outputs distances once complete
    }

    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), m = Integer.parseInt(line[1]);
        int[][] graph = new int[n][n];
        for (int i = 0; i < m; i++){
            line = br.readLine().split(" ");
            int l = Integer.parseInt(line[0]), r = Integer.parseInt(line[1]), w = Integer.parseInt(line[2]);
            //graph is undirected AND there can be multiple edges between 2 nodes (so we find the lowest weight for one edge to another)
            if (graph[l-1][r-1] == 0 && graph[r-1][l-1] == 0) {
                graph[l-1][r-1] = w;
                graph[r-1][l-1] = w;
            }
            else {
                graph[l-1][r-1] = Math.min(graph[l-1][r-1], w);
                graph[r-1][l-1] = Math.min(graph[r-1][l-1], w);
            }
        }
        dijkstra(graph, 0);
    }
}
