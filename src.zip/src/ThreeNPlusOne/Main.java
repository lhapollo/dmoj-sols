package ThreeNPlusOne;

import java.util.*;
import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        int y = 0;
        while (n != 1){
            if (n % 2 == 0){
                n = n / 2;
            } else{
                n = (n * 3) + 1;
            }
            y++;
        }
        System.out.println(y);
    }
}
