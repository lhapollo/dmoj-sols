package WordScrambler;

import java.io.*;
import java.util.*;

public class Main {
    static TreeSet<String> permutations = new TreeSet<String>();

    static void permute(String s, String answer){
        if(s.length() == 0){
            permutations.add(answer);
            return;
        }

        for (int i = 0; i < s.length(); i++){
            char ch = s.charAt(i);
            String left_sub = s.substring(0, i);
            String right_sub = s.substring(i+1);
            String rest = left_sub + right_sub;
            permute(rest, answer + ch);
        }
    }

    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s = br.readLine();
        String ans = "";
        permute(s,ans);
        for (String st: permutations){
            System.out.println(st);
        }
    }
}
