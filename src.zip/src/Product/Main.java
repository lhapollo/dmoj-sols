package Product;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
        long x, y;
        String[] line = b.readLine().split(" ");

        x = Long.parseLong(line[0]);
        y = Long.parseLong(line[1]);

        System.out.println(x * y);
    }
}
