package OperatorSimulation;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        String[] data = br.readLine().split(" ");
        String output = "";

        switch (data[1]){
            case "|":
                for (int i = 0; i < n; i++){
                    if (data[0].charAt(i) == '1' || data[2].charAt(i) == '1'){
                        output += "1";
                    } else {
                        output += "0";
                    }
                }
                break;
            case "&":
                for (int i = 0; i < n; i++){
                    if (data[0].charAt(i) == '1' && data[2].charAt(i) == '1'){
                        output += "1";
                    } else {
                        output += "0";
                    }
                }
                break;
            case "^":
                for (int i = 0; i < n; i++){
                    if (data[0].charAt(i) == '1' && data[2].charAt(i) == '0'){
                        output += "1";
                    } else if (data[0].charAt(i) == '0' && data[2].charAt(i) == '1'){
                        output += "1";
                    }
                    else {
                        output += "0";
                    }
                }
                break;
        }
        System.out.println(output);
    }
}
