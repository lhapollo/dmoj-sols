package WorkoutRoutine;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        long n = Long.parseLong(line[0]), k = Long.parseLong(line[1]);
        long total = 0;
        for (long i = 1; i <= n-1; i++){
            System.out.print(i + " ");
            total += i;
        }
        for (long i = n-1; i < 1000000000; i++){
            if ((total + i) % k == 0){
                System.out.print(i);
                break;
            }
        }
    }
}
