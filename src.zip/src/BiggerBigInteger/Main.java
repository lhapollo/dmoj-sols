package BiggerBigInteger;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int d = Integer.parseInt(br.readLine());
        String l = br.readLine();
        String fin = "";
        for (int i = 0; i < d - 1; i++){
            if (Integer.parseInt(""+l.charAt(i)) < Integer.parseInt(""+l.charAt(i+1))){
                fin += l.substring(0, i);
                fin += l.charAt(i+1);
                fin += l.charAt(i);
                fin += l.substring(i+2);
                break;}
        }
        if (fin.length() == 0) System.out.println(l);
        else System.out.println(fin);
    }
}
