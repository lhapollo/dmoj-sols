package ANoisyClass;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        int m = Integer.parseInt(br.readLine());
        int[][] graph = new int[n][n];
        boolean cycle = false;
        for (int i = 0; i < m; i++){
            String[] line = br.readLine().split(" ");
            //a -> b
            int a = Integer.parseInt(line[0]);
            int b = Integer.parseInt(line[1]);
            graph[a-1][b-1] = 1;

            if (graph[b-1][a-1] == graph[a-1][b-1] && graph[b-1][a-1] != 0){
                cycle = true;
                break;
            }
        }
        System.out.println(cycle ? "N" : "Y");
    }
}
