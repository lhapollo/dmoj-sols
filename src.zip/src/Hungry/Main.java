package Hungry;

import java.io.*;
import java.util.HashMap;
import java.util.*;

public class Main {

    public static void main(String[] args) throws Exception {
        HashMap<Long, Integer> filling = new HashMap<>();
        HashMap<Long, Integer> taste = new HashMap<>();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());

        for (int i = 1; i <= n; i++){
            String[] fillingTasty = br.readLine().split(" ");
            taste.put(Long.parseLong(fillingTasty[1]), i);
            filling.put(Long.parseLong(fillingTasty[0]), i);
        }

        System.out.println(filling);
        System.out.println(taste);
        System.out.println();
        ArrayList<Long> fillings = new ArrayList<>(filling.keySet());
        Collections.sort(fillings);

        ArrayList<Long> tastes = new ArrayList<>(taste.keySet());
        Collections.sort(tastes);

        System.out.println(filling);
        System.out.println(fillings);
        System.out.println();
        System.out.println(taste);
        System.out.println(tastes);

//        for (int i = 0; i < fillings.size(); i++){
//            System.out.print (fillings.get(i) + " ");
//        }for (int i = 0; i < tastes.size(); i++){
//            System.out.print (tastes.get(i) + " ");
//        }



    }
}
