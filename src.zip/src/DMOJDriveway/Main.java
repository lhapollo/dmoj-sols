package DMOJDriveway;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        LinkedList<String> cars = new LinkedList<>();
        String[] line = br.readLine().split(" ");
        int t = Integer.parseInt(line[0]), m = Integer.parseInt(line[1]);
        for (int i = 0; i < t; i++){
            line = br.readLine().split(" ");
            if (line[1].equals("in")) cars.addLast(line[0]);
            else if (line[1].equals("out")){
                if (cars.getLast().equals(line[0])) cars.removeLast();
                else if (cars.getFirst().equals(line[0]) && m >= 1){
                    cars.removeFirst();
                    m--;
                }
            }
        }
        for (String car: cars){
            System.out.println(car);
        }
    }
}
