package AlanIsTakingTheBus;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        ArrayList<ArrayList<Integer>> adjList = new ArrayList<ArrayList<Integer>>();
        String[] line = br.readLine().split(" ");
        boolean canOrNot = false;
        int n = Integer.parseInt(line[0]), m = Integer.parseInt(line[1]);
        //initializing adjList
        for (int i = 0; i < n; i++) {
            adjList.add(new ArrayList<>());
        }
        for (int i = 0; i < m; i++) {
            line = br.readLine().split(" ");
            adjList.get(Integer.parseInt(line[0]) - 1).add(Integer.parseInt(line[1]));
            adjList.get(Integer.parseInt(line[1]) - 1).add(Integer.parseInt(line[0]));
        }
        line = br.readLine().split(" ");
        if (adjList.get(Integer.parseInt(line[0]) - 1).contains(Integer.parseInt(line[1])) || adjList.get(Integer.parseInt(line[1]) - 1).contains(Integer.parseInt(line[0]))) {
            canOrNot = true;
        } else {
            for (ArrayList<Integer> arr : adjList) {
                if (arr.contains(Integer.parseInt(line[0])) && arr.contains(Integer.parseInt(line[1]))) {
                    canOrNot = true;
                    break;
                }
            }
        }
        System.out.println(canOrNot? "yay! no complaint.":"aww man! whiny Alan.");
    }
}
