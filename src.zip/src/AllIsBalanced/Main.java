package AllIsBalanced;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        for (int i = 0; i < 5; i++){
            Stack<Character> left = new Stack<Character>();
            boolean can = true;
            String s = br.readLine();
            for (int j = 0; j < s.length(); j++){
                if (s.charAt(j) == '(' || s.charAt(j) == '{' || s.charAt(j) == '['){
                    left.push(s.charAt(j));
                } else if (s.charAt(j) == ')' || s.charAt(j) == '}' || s.charAt(j) == ']'){
                    if (!left.empty()){
                        if (s.charAt(j) == ')' && left.peek() != '(' || s.charAt(j) == '}' && left.peek() != '{' || s.charAt(j) == ']' && left.peek() != '['){
                            can = false;
                            break;
                        } else {
                            left.pop();
                        }
                    } else {
                        can = false;
                        break;
                    }
                }
            }
            System.out.println(can ? "balanced" : "not balanced");
        }
    }
}
