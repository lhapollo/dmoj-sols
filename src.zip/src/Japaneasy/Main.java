package Japaneasy;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int T = Integer.parseInt(br.readLine());
        String vowels = "aeiou";
        String japLetters = "knhmr";
        for (int i = 0; i < T; i++){
            boolean yes = true;
            String s = br.readLine();
            if (japLetters.contains(""+s.charAt(s.length()-1)) || s.charAt(s.length()-1) == 'f'){
                System.out.println("NO");
                continue;
            }
            for (int j = 0; j < s.length(); j++){
                if (s.charAt(j) == 'f' && s.charAt(j+1) != 'u'){
                    yes = false;
                    System.out.println("NO");
                    break;
                }
                else if (japLetters.contains(""+s.charAt(j))){
                    if(!vowels.contains(""+s.charAt(j+1)) || (s.charAt(j) == 'h' && s.charAt(j+1) == 'u')){
                        System.out.println("NO");
                        yes = false;
                        break;
                    }
                } else if (s.charAt(j) != 'f' && !vowels.contains(""+s.charAt(j))){
                    System.out.println("NO");
                    yes = false;
                    break;
                }
            }
            if (yes) System.out.println("YES");
        }
    }
}