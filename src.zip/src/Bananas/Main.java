package Bananas;

import java.io.*;

public class Main {
    public static boolean isMonkey(String s){
        if (isA(s)) return true;
        for (int i = 1; i < s.length(); i++){
            if (s.charAt(i) == 'N'){
                if (isA(s.substring(0, i)) && isMonkey(s.substring(i+1))) return true;
            }
        }
        return false;
    }

    public static boolean isA(String s) {
        if (s.equals("A")) return true;
        else return s.length() > 1 && s.charAt(0) == 'B' && s.charAt(s.length() - 1) == 'S' && isMonkey(s.substring(1, s.length() - 1));
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s = "";
        while(!s.equals("X")){
            s = br.readLine();
            if (s.equals("X")) break;
            else System.out.println(isMonkey(s)? "YES":"NO");
        }
    }
}
