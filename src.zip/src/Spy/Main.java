package Spy;

import java.io.*;

//65 to 90 ASCII (A-Z)
//97 to 122 ASCII (a-z)

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String output = "";
        String c = br.readLine();
        String e = br.readLine();
        for (int i = 0; i <= c.length()-2; i+=2){
            int l1 = Integer.parseInt(c.substring(i, i+2));
            int l2 = Integer.parseInt(e.substring(i, i+2));
            int letter = 64 + l2 - l1;
            char character = (char) letter;
            output += "" + character;
        }
        System.out.println(output);
    }
}
