package AUniqueList;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        String[] line = br.readLine().split(" ");
        TreeSet<Integer> sorted = new TreeSet<>();

        for (int i = 0; i < n; i++){
            sorted.add(Integer.parseInt(line[i]));
        }
        String output = (""+sorted).substring(1,(""+sorted).length()-1).replaceAll("[,]","");
        System.out.println(output);
    }
}
