package RookProblem;

import java.io.*;
import java.util.*;

public class Main {
    static long factorial(int n){
        long prod = 1;
        for (int i = n; i > 0; i--) prod *= i;
        return prod;
    }
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), k = Integer.parseInt(line[1]);
        long r = (factorial(n) * factorial(n)) / (factorial(k) * factorial(n-k) * factorial(n-k));
        System.out.println(r);
    }
}
