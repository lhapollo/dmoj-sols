package ModuloSort;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int m = Integer.parseInt(reader.readLine()), k = Integer.parseInt(reader.readLine());
        String[] line = reader.readLine().split(" ");

        ArrayList<ArrayList<Long>> v = new ArrayList<ArrayList<Long>>(k);

        //adding k empty vectors inside arrayList
        for (int i = 0; i < k; i++){
            v.add(new ArrayList<Long>());
        }
        //updating vectors so v[i] are all elements giving remainder as i, when divided by k
        for (int i = 0; i < m; i++){
            int t = (int) (Long.parseLong(line[i]) % k);
            v.get(t).add(Long.parseLong(line[i]));
        }
        for (int i = 0; i < k; i++){
            Collections.sort(v.get(i));
        }
        System.out.println((""+v).replace("[", "").replace("]","").replace(",",""));

    }
}
