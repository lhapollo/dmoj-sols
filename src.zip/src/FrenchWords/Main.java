package FrenchWords;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        TreeSet<String> sWords = new TreeSet<String>();
        TreeSet<String> aWords = new TreeSet<String>();
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]);
        int m = Integer.parseInt(line[1]);
        int shared = 0;

        line = br.readLine().split(" ");
        for (int i = 0; i < n; i++) {
            sWords.add(line[i]);
        }
        line = br.readLine().split(" ");
        for (int i = 0; i < m; i++) {
            aWords.add(line[i]);
        }
        for (String w: sWords){
            if (aWords.contains(w)) shared++;
        }
        System.out.println(shared);
    }
}
