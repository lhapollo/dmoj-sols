package LetterFrequency;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s = br.readLine();
        int n = s.length() + 1;
        int[][] arr = new int[26][n];
        for (int i = 0; i < 26; i++) arr[i][0] = 0;
        String letters = "abcdefghijklmnopqrstuvwxyz";
        for (int i = 0; i < s.length(); i++){
            for (int j = 0; j < 26; j++){
                arr[j][i+1] = arr[j][i];
            }
            if (letters.contains(""+s.charAt(i))){
                arr[letters.indexOf(s.charAt(i))][i+1]++;
            }
        }
        int q = Integer.parseInt(br.readLine());
        for (int i = 0; i < q; i++){
            String[] line = br.readLine().split(" ");
            int l = Integer.parseInt(line[0]), r = Integer.parseInt(line[1]);
            char ch = line[2].charAt(0);
            System.out.println(arr[letters.indexOf(ch)][r]- arr[letters.indexOf(ch)][l-1]);

        }
    }
}
