package ADividingProblem;

import java.util.*;

public class Main {
    static long gcf(long a, long b){
        if (a == 0){
            return b;
        }
        return gcf(b % a, a);
    }

    public static void main(String[] args){
        Scanner s= new Scanner(System.in);
        int n = s.nextInt();
        long[] a = new long[n];
        for (int i = 0; i < n; i++){
            a[i] = s.nextLong();
        }
        long g = a[0];
        for (int i = 1; i < n; i++){
            g = gcf(a[i], g);
        }
        System.out.println(g);
    }
}
