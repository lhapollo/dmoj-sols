package Mints;

import java.util.*;

public class Main {
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        int[] mints = new int[n];

        for (int i = 0; i < n; i++){
            mints[i] = s.nextInt();
        }

        Arrays.sort(mints);

        System.out.println(mints[n-2]);
    }
}
