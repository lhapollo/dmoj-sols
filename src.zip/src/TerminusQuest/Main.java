package TerminusQuest;

import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        String[] data = br.readLine().split(" ");
        int d = Integer.parseInt(data[1]) - Integer.parseInt(data[0]);
        boolean arithmetic = true;

        for (int i = n-1;i > 0; i--){
            if (Integer.parseInt(data[i]) - Integer.parseInt(data[i-1]) != d){
                arithmetic = false;
                break;
            }
        }

        if (arithmetic){
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
    }
}
