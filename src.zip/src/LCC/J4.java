package LCC;

import java.io.*;
import java.util.*;

public class J4 {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), r = Integer.parseInt(line[1]);
        HashMap<Integer, Integer> count = new HashMap<>();
        int[] score = new int[n];
        for (int i = 0; i < n; i++){
            int l, p;
            line = br.readLine().split(" ");
            l = Integer.parseInt(line[0]);
            p = Integer.parseInt(line[1]);
            count.put(l, count.getOrDefault(l, 0)+1);
            score[i] = p;
        }
        ArrayList<Integer> lvls = new ArrayList<Integer>(count.keySet());
    }
}
