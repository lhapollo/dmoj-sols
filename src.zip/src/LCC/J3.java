package LCC;

import java.io.*;
import java.util.*;

public class J3 {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n, m;
        String[] line = br.readLine().split(" ");
        n = Integer.parseInt(line[0]);
        m = Integer.parseInt(line[1]);
        int[] arr = new int[n];
        Arrays.fill(arr, -1); //off
        for (int i = 0; i < m; i++){
            int in = Integer.parseInt(br.readLine());
            if (in == 1){
                arr[0] *= -1;
                arr[1] *= -1;
            } else if (in == n){
                arr[n-1] *= -1;
                arr[n-2] *= -1;
            } else {
                arr[in-1] *= -1;
                arr[in] *= -1;
                arr[in-2] *= -1;
            }
        }
        for (int i = 0; i < n; i++){
            if (arr[i] == 1) System.out.print((i+1) + " ");
        }
    }
}
