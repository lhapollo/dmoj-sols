package ColdCompress;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        for (int i = 0; i < n; i++){
            String line = br.readLine();
            LinkedHashMap<Character, Integer> signs = new LinkedHashMap<Character, Integer>();
            for (int j = 0; j < line.length(); j++){
                signs.put(line.charAt(j), signs.getOrDefault(line.charAt(j), 0) + 1);
            }
            for (char a: signs.keySet()){
                System.out.print(signs.get(a) + " " + a + " ");
            }
            System.out.println();
        }
    }
}
