package FizzCoke;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        HashMap<Integer, String> map = new HashMap<Integer, String>();
        int m = Integer.parseInt(line[0]), n = Integer.parseInt(line[1]);
        for (int i = 0; i < m; i++){
            line = br.readLine().split(" ");
            int num = Integer.parseInt(line[0]);
            String w = line[1];
            map.put(num,w);
        }
        for (int i = 1; i <= n; i++){
            String test = "";
            for (int num : map.keySet()){
                test += (i%num) == 0 ? map.get(num):"";
            }
            System.out.println(!test.isEmpty()?test:i);
        }
    }
}
