package ConspicuousCrypticChecklist;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), m = Integer.parseInt(line[1]);
        HashSet<String> og = new HashSet<>();
        int count = 0;
        for (int i = 0; i < n; i++) og.add(br.readLine());
        for (int i = 0; i < m; i++){
            int t = Integer.parseInt(br.readLine());
            boolean yes = true;
            for (int j = 0; j < t; j++){
                String check = br.readLine();
                if (!og.contains(check)){
                    yes = false;
                    //break;
                }
            }
            if (yes) count++;
        }
        System.out.println(count);
    }
}
