package AlpacaRacing;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        long d, p;
        int n, k, x;
        String[] line = br.readLine().split(" ");
        n = Integer.parseInt(line[0]);
        d = Long.parseLong(line[1]);
        k = Integer.parseInt(line[2]);
        x = Integer.parseInt(line[3]);

        long[] speeds = new long[n];

        for (int i = 0; i < n; i++){
            speeds[i] = Long.parseLong(br.readLine());
        }

        p = Long.parseLong(br.readLine());

        int index = 0;
        int count = 0;

        Arrays.sort(speeds);

        while (count < k){
            if (index == n) break;
            else if (p <= speeds[index]){
                speeds[index] = (long) Math.floor(speeds[index] * ((100 - x) / 100.0));
                count++;
            }

            if (speeds[index] < p) index++;
        }

        //System.out.println(Arrays.toString(speeds));

        boolean wins = true;

        for (long speed: speeds){
            if (p <= speed){
                wins = false;
                break;
            }
        }

        if (wins) System.out.println("YES");
        else System.out.println("NO");
    }
}
