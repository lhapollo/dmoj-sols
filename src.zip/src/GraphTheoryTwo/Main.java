package GraphTheoryTwo;

import java.util.*;

public class Main {
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        long n = s.nextLong();
        long k = s.nextLong();

        if (n <= k){
            System.out.println("Scam!");
        } else {
            System.out.println("Graph Theory!");
        }
    }
}
