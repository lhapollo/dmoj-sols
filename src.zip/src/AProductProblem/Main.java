package AProductProblem;

import java.io.*;
import java.math.BigInteger;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        BigInteger a = new BigInteger(line[0]);
        BigInteger b = new BigInteger(line[1]);
        BigInteger expo = BigInteger.valueOf(10).pow(9);
        BigInteger mod = expo.add(BigInteger.valueOf(7));
        BigInteger value = a.multiply(b).mod(mod);
        System.out.println(value);
    }
}
