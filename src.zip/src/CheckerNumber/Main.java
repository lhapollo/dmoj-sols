package CheckerNumber;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        long t = Long.parseLong(br.readLine());
        long[] squares = new long[1000000000];
        for (int i = 0; i <= 1000000000; i++){
            squares[i] = (long) i * i;
        }
        for (int i = 0; i < t; i++){
            long n = Long.parseLong(br.readLine());
            long root = 0, diff = 0;
            root = Arrays.binarySearch(squares, n);
            if (root < 0) root = Math.abs(root) -1;
            diff = n - (root * root);
            long output = (long) (Math.ceil(root/9.0) + Math.ceil(diff/9.0));
            if (output % 2 == 1) output++;
            System.out.println(output);
        }
    }
}
