package BrapLeshMafia;

import java.io.*;
import java.math.BigInteger;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]);
        BigInteger k = new BigInteger(line[1]);
        BigInteger out = new BigInteger("0");
        for (int i = 0; i < n; i++){
            line = br.readLine().split(" ");
            BigInteger a = new BigInteger(line[0]);
            BigInteger b = new BigInteger(line[1]);
            BigInteger ab = a.multiply(b);
            out = out.add(ab);
        }
        out = out.mod(k);
        System.out.println(out);

    }
}
