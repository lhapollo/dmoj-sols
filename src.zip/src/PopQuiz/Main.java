package PopQuiz;

import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        boolean perfect = true;
        for (int i = 0; i < n; i++){
            String[] line = br.readLine().split(" ");
            if (Integer.parseInt(line[0]) * Integer.parseInt(line[1]) != Integer.parseInt(line[2])){
                perfect = false;
                break;
            }
        }
        if (perfect){
            System.out.println("PERFECT");
        } else {
            System.out.println("IMPERFECT");
        }
    }
}
