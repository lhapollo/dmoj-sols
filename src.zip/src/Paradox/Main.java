package Paradox;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        HashSet<Boolean> set = new HashSet<Boolean>();
        int c = Integer.parseInt(br.readLine());
        for (int i =0; i < c; i++){
            boolean b;
            String[] line = br.readLine().split(" ");
            if (Integer.parseInt(line[0]) == 1){
                b = line[1].equals("true");
                System.out.println(set.contains(b));
                set.add(b);
            } else if (Integer.parseInt(line[0]) == 2){
                b = line[1].equals("true");
                System.out.println(set.contains(b));
                set.remove(b);
            } else if (Integer.parseInt(line[0]) == 3){
                b = line[1].equals("true");
                ArrayList<Boolean> list = new ArrayList<Boolean>(set);
                System.out.println(list.indexOf(b));
            } else if (Integer.parseInt(line[0]) == 4){
                System.out.println((""+set).replace("[","").replaceAll("]","").replace(",",""));
            }
        }
    }
}
