package ABaseProblem;

import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int base = Integer.parseInt(br.readLine());
        long a = Long.parseLong(br.readLine(), base);
        long b = Long.parseLong(br.readLine(), base);

        System.out.println(Long.toString(a + b, base));
        System.out.println(Long.toString(a * b, base));
    }
}
