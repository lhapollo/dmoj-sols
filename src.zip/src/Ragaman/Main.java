package Ragaman;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String a = br.readLine();
        String b = br.readLine();
        HashMap<Character, Integer> aCount = new HashMap<Character, Integer>();
        HashMap<Character, Integer> bCount = new HashMap<Character, Integer>();
        int asterisks = 0;
        for (int i = 0; i < a.length(); i++){
            aCount.put(a.charAt(i), aCount.getOrDefault(a.charAt(i), 0)+1);
            if (b.charAt(i) == '*') asterisks++;
            else bCount.put(b.charAt(i), bCount.getOrDefault(b.charAt(i), 0)+1);
        }
        boolean can = true;
        if (a.length() != b.length()) can = false;
        for (char c: bCount.keySet()){
            if (bCount.get(c) > aCount.getOrDefault(c,0)){
                can = false;
                break;
            }
        }
        System.out.println(can? "A":"N");
    }
}
