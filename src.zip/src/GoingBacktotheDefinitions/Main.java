package GoingBacktotheDefinitions;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        ArrayList<String> al = new ArrayList<>();
        for (int i = 0; i < n; i++){
            al.add(br.readLine());
        }
        for (int i = 0; i < n; i++){
            for (int j = i+1; j < n; j++){
                if ((al.get(i) + al.get(j)).compareTo(al.get(j) + al.get(i)) > 0){
                    String temp = al.get(i);
                    al.set(i, al.get(j));
                    al.set(j, temp);
                }
            }
        }
        String ans = "";
        for (String s: al) ans += s;
        System.out.println(ans);
    }
}
