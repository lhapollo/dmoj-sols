package TracysWPM;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception{
         BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
         int n = Integer.parseInt(b.readLine());
         String[] mk = b.readLine().split(" ");
         double m = Double.parseDouble(mk[0]);
         double k = Double.parseDouble(mk[1]);

         long enhancedHrs = (int) Math.ceil(m/k);
         long maxEnhanced = (int) Math.floor(m/k);
         long leftOverEnhanced = enhancedHrs - maxEnhanced;
         long noEnhanced = n - enhancedHrs;

         long maxBoost = (long) ((k*(k+1)) / 2) + 18;
         long leftOverBoost = (long) (((m % k) * ((m % k) + 1)) / 2) + 18;

         long words = 0;

         words = (maxBoost * maxEnhanced * 60) + (leftOverBoost * leftOverEnhanced * 60) + (noEnhanced * 18 * 60);

         System.out.println(words);
    }
}
