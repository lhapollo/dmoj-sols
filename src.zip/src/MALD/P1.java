package MALD;

import java.io.*;
import java.util.*;

public class P1 {
    public static TreeSet<String> Can = new TreeSet<>();
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        String[] arr = new String[n];
        for (int i = 0; i < n; i++){
            arr[i] = br.readLine();
        }
        for (int i = 0; i < n; i++){
            if (arr[i].contains("yubo")){
                if (i == 0) {
                    Can.add(arr[i]);
                    if (n > 1) Can.add(arr[i+1]);
                } else if (i == n-1){
                    Can.add(arr[i]);
                    Can.add(arr[i-1]);
                } else{
                    Can.add(arr[i]);
                    Can.add(arr[i+1]);
                    Can.add(arr[i-1]);
                }
            }
        }
        for (String s: Can) System.out.println(s);
    }
}
