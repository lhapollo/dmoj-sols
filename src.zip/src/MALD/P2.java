package MALD;

import java.io.*;

public class P2 {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(br.readLine());
        for (int i = 0; i < t; i++){
            String[] line = br.readLine().split(" ");
            long g = Long.parseLong(line[0]), p = Long.parseLong(line[1]);
            double percent = ((g*1.0)/p)*100;
            //System.out.println(Math.ceil(percent));
            if (Math.ceil(percent) > 100) System.out.println("sus");
            else if (Math.ceil(percent) == 100.0) System.out.println("average");
            else if (Math.ceil(percent) <= 99.0 && Math.ceil(percent) >= 98.0) System.out.println("below average");
            else if (Math.ceil(percent) <= 97.0 && Math.ceil(percent) >= 95.0) System.out.println("can't eat dinner");
            else if (Math.ceil(percent) <= 94.0 && Math.ceil(percent) >= 90.0) System.out.println("don't come home");
            else if (Math.ceil(percent) < 90.0) System.out.println("find a new home");
        }
    }
}
