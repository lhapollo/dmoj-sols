package Grades;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        ArrayList<Character> grades = new ArrayList<Character>();
        int t = Integer.parseInt(br.readLine());
        for (int i = 0; i < t; i++){
            int grade = Integer.parseInt(br.readLine());
            if (grade >= 80 && grade <= 100){
                grades.add('A');
            } else if (grade >= 70 && grade <= 79){
                grades.add('B');
            } else if (grade >= 60 && grade <= 69){
                grades.add('C');
            } else if (grade >= 50 && grade <= 59){
                grades.add('D');
            } else if (grade >= 0 && grade <= 49){
                grades.add('F');
            } else{
                grades.add('X');
            }
        }
        for (char grade: grades){
            System.out.println(grade);
        }
    }
}
