package SantaAndPipes;

import java.io.*;
import java.util.*;

public class Main {
    static int n, m;
    static ArrayList<Integer>[] adjList;
    static boolean[] visited;

    // exact same dfs implementation as before
    static void dfs(int node) { /* … */ }
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        n = s.nextInt(); m = s.nextInt();
        //adjList = new ArrayList<Integer>[n + 1];
        for(int i = 1; i <= n; i++) adjList[i] = new ArrayList();
        for(int i = 0; i < m; i++) adjList[s.nextInt()].add(s.nextInt());
        visited = new boolean[n + 1]; // default initialized to false
        dfs(1);
        for(int i = 1; i <= n; i++) {
            if(!visited[i]) {
                System.out.println("NO"); return;
            }
        }
        System.out.println("YES"); return;
    }
}
