package DynamicProgramming;

import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String s = reader.readLine();

        if (s.equals("dp")){
            System.out.println("dynamicprogramming");
        } else if (s.equals("dynamicprogramming")){
            System.out.println("dp");
        } else System.out.println(s);
    }
}
