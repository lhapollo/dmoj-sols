package KnittingScarves;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), q = Integer.parseInt(line[1]);
        ArrayList<Integer> al = new ArrayList<Integer>();
        for (int i = 1; i <= n; i++) al.add(i);
        for (int i = 0; i < q; i++){
            line = br.readLine().split(" ");
            List <Integer> chunk;
            int l = Integer.parseInt(line[0]), r = Integer.parseInt(line[1]), k = Integer.parseInt(line[2]);
            chunk = al.subList(al.indexOf(l),al.indexOf(r)+1);
            Collections.rotate(chunk, Math.abs(al.indexOf(l)-al.indexOf(k))*-1);
            System.out.println(al);
        }
    }
}
