package StringProblem;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String a = br.readLine();
        String b = br.readLine();

        HashMap<Character, Integer> aChars = new HashMap<Character, Integer>();
        HashMap<Character,Integer> bChars = new HashMap<Character, Integer>();

        boolean canBuild = true;

        for (int i = 0; i < a.length(); i++){
            aChars.put(a.charAt(i), aChars.getOrDefault(a.charAt(i),0)+1);
        }
        for (int i = 0; i < b.length();i++){
            bChars.put(b.charAt(i), bChars.getOrDefault(b.charAt(i),0)+1);
        }
        for (char c: aChars.keySet()){
            if (!bChars.containsKey(c)){
                canBuild = false;
                break;
            } else{
                if (aChars.get(c) > bChars.get(c)) {
                    canBuild = false;
                    break;
                }
            }
        }
//        System.out.println(aChars);
//        System.out.println(bChars);
        System.out.println(canBuild? "YES":"NO");
    }
}
