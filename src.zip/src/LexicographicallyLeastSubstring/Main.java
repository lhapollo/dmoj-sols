package LexicographicallyLeastSubstring;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        ArrayList<String> substrings = new ArrayList<String>();
        String s = br.readLine();
        int k = Integer.parseInt(br.readLine());

        for (int i = 0; i < s.length() - k; i++){
            substrings.add(s.substring(i,i+k));
        }

        Collections.sort(substrings);
        System.out.println(substrings.get(0));
    }
}
