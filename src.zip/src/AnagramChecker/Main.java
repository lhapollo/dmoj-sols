package AnagramChecker;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s1, s2;
        s1 = br.readLine();
        s2 = br.readLine();
        char[] one = s1.toCharArray();
        char[] two = s2.toCharArray();
        Arrays.sort(one);
        Arrays.sort(two);
        String t1 = String.copyValueOf(one);
        String t2 = String.copyValueOf(two);
        if (s1.length() >= s2.length()){
            System.out.println(t1.contains(t2)? "Is an anagram." : "Is not an anagram.");
        } else {
            System.out.println(t2.contains(t1)? "Is an anagram." : "Is not an anagram.");
        }
    }
}
