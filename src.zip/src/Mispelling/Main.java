package Mispelling;

import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        for (int i = 1; i <= n; i++){
            String[] line = br.readLine().split(" ");
            int index = Integer.parseInt((line[0]));
            String s = "";
            for (int j = 1; j < line.length; j++){
                s += line[j] + " ";
            }
            s = s.trim();
            if (index == s.length()){
                System.out.println(i + " " + s.substring(0, index-1));
            }
            else{
                System.out.println(i + " " + s.substring(0, index - 1) + s.substring(index));
            }
        }
    }
}
