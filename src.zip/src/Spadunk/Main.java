package Spadunk;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
        double x, y;
        int m;

        String[] data;

        data = r.readLine().split(" ");

        x = Double.parseDouble(data[0]);
        y = Double.parseDouble(data[1]);

        double finalx = x;
        double finaly = y;

        m = Integer.parseInt(r.readLine());

        double addx = 0;
        double multiplyx = 1;

        double addy = 0;
        double multiplyy = 1;

        for (int i = 0; i < m; i++) {
            data = r.readLine().split(" ");
            switch (data[0]) {
                case "1":
                    addx += Double.parseDouble(data[1]);
                    addy += Double.parseDouble(data[2]);
                    break;
                case "2":
                    multiplyx *= Double.parseDouble(data[1]);
                    addx *= Double.parseDouble(data[1]);
                    multiplyy *= Double.parseDouble(data[1]);
                    addy *= Double.parseDouble(data[1]);
                    break;
                case "3":
                    finalx = (multiplyx * x) + addx;
                    finaly = (multiplyy * y) + addy;
                    x = finalx;
                    y = finaly;
                default:
                    break;
            }
//            System.out.println(multiplyx + "(" + x + ")  + " + addx);
//            System.out.println(multiplyy + "(" + y + ")  + " + addy);
        }

        System.out.printf("%.2f", x);
        System.out.print(" ");
        System.out.printf("%.2f", y);
    }
}
