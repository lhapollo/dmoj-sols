package GenevaConfection;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args)throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(br.readLine());
        for (int i = 0; i < t; i++){
            Stack<Integer> mountain = new Stack<Integer>();
            Stack<Integer> branch = new Stack<Integer>();
            branch.push(0);
            int n = Integer.parseInt(br.readLine());
            for (int j = 0; j < n; j++){
                int a = Integer.parseInt(br.readLine());
                mountain.push(a);
            }
            int temp = 1; //what you're looking for to put in the lake
            int currMin = 0;
            boolean can = true;
            for (int j = 0; j < n; j++){ //loops through all n elements initially in mountain stack
                int x = mountain.pop(); //x stores the value of top of stack
                if (x == temp) temp++; //found target, can now move onto temp + 1
                else {
                    //branch stack will always have at least 1 element ("0")
                    if (branch.peek() == temp) branch.pop();
                    else {
                        if (branch.size() == 1){
                            currMin = x;
                            branch.push(x);
                        } else{
                            if (x > currMin){
                                can = false;
                                break;
                            }
                        }
                    }
                }
            }
            System.out.println(can? "Y" : "N");
        }
    }
}
