package TracyandBakeries;

import java.io.*;
import java.util.*;

public class Main {
    public static long max = 0;
    public static void addScore(int node, long score, boolean[] status, int[] scores, HashMap<Integer, ArrayList<Integer>> graph){
        status[node-1] = true;
        score += scores[node-1];
        //System.out.println(score);
        if (score > max){
            max = score;
        }
        for (int links: graph.get(node)){
            if (!status[links - 1]){
                addScore(links, score, status, scores, graph);
            }
        }
    }
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        HashMap<Integer, ArrayList<Integer>> graph = new HashMap<Integer, ArrayList<Integer>>();
        int[] scores = new int[n];
        boolean[] visited = new boolean[n];
        String[] line = br.readLine().split(" ");

        //initialising graph
        for (int i = 1; i <= n; i++){
            graph.put(i, new ArrayList<>());
        }

        //initialising scores
        for (int i = 0; i < n; i++){
            scores[i] = Integer.parseInt(line[i]);
        }

        //getting links from graph
        for (int i = 0; i < n-1; i++){
            line = br.readLine().split(" ");
            graph.get(Integer.parseInt(line[0])).add(Integer.parseInt(line[1]));
            graph.get(Integer.parseInt(line[1])).add(Integer.parseInt(line[0]));
        }
        max = scores[0];
        addScore(1, 0, visited, scores, graph);
        System.out.println(max);
    }
}
