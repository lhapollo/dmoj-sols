package KoalaKonundrum;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        String s = br.readLine();
        HashMap<Character, Integer> count = new HashMap<>();
        for (int i = 0; i < n; i++){
            count.put(s.charAt(i), count.getOrDefault(s.charAt(i), 0) + 1);
        }
        int oddCount = 0;
        for (int i: count.values()){
            if (i % 2 != 0) oddCount++;
        }
        System.out.println(Math.max(oddCount, 1));
    }
}
