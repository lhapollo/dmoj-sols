package Calendar;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        ArrayList<String> output = new ArrayList<String>();
        int day = Integer.parseInt(line[0]), numDays = Integer.parseInt(line[1]);
        System.out.println("Sun Mon Tue Wed Thr Fri Sat");
        int curr = day-1;
        String s = "";
        for (int i = 0; i < 4*curr; i++){
            s += " ";
        }
        for (int i = 1; i <= numDays; i++){
            if (curr % 7 == 6) {
                if (i < 10) s += "   " + i;
                else s += "  " + i;
                output.add(s);
                s = s.replace(s,"");
            }
            else if (curr % 7 == 0){
                if (i < 10) s += "  " + i;
                else s += " " + i;
            }
            else {
                if (i == 1) s += "  " + i;
                else if (i < 10) s += "   " + i;
                else s += "  " + i;
            }
            curr++;
        }
        output.add(s);
        for (String a: output) {
            a = a.replaceFirst("\\s++$","");
            System.out.println(a);
        }
        System.out.println();
    }
}
