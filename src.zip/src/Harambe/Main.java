package Harambe;

import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s = br.readLine();
        int upper = 0, lower = 0;
        for (int i = 0 ; i < s.length(); i++){
            int value = (int) s.charAt(i);
            if (value >= 65 && value <= 90) upper++;
            else if (value >= 97 && value <= 122) lower++;
        }
        if (lower == upper) System.out.println(s);
        else if (lower > upper){
            System.out.println(s.toLowerCase());
        }
        else {
           System.out.println(s.toUpperCase());
        }
    }
}
