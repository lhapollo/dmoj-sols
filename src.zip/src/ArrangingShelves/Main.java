package ArrangingShelves;

import java.io.*;

public class Main {
    static int[] getCount(String shelf){
        int[] arr = {0,0,0};
        for (int i = 0; i < shelf.length(); i++){
            if (shelf.charAt(i) == 'L') arr[0]++;
            else if (shelf.charAt(i) == 'M') arr[1]++;
            else arr[2]++;
        }
        return arr;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String shelf = br.readLine();
        int lCount = getCount(shelf)[0], mCount = getCount(shelf)[1], sCount = getCount(shelf)[2];
        int[] sectL = getCount(shelf.substring(0,lCount)), sectM = getCount(shelf.substring(lCount, lCount+mCount)), sectS = getCount(shelf.substring(lCount+mCount));
        int sinSwap = Math.min(sectL[1],sectM[0]) + Math.min(sectL[2],sectS[0]) + Math.min(sectM[2],sectS[1]);

        int x = Math.min(sectL[1], sectM[0]);

        sectL[1] -= x;
        sectM[0] -= x;
        sectL[0] += x;
        sectM[1] += x;

        x = Math.min(sectL[2], sectS[0]);

        sectL[2] -= x;
        sectS[0] -= x;
        sectL[0] += x;
        sectS[2] += x;

        x = Math.min(sectM[2], sectS[1]);

        sectM[2] -= x;
        sectS[1] -= x;
        sectM[1] += x;
        sectS[2] += x;

        int doubSwap = 2 * (sectL[1] + sectL[2]);

        System.out.println(sinSwap + doubSwap);
    }
}
