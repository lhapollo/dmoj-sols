package CuttingLogs;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int l = Integer.parseInt(br.readLine());
        String[] good = br.readLine().split("X");
        ArrayList<String> out = new ArrayList<String>();
        for (String i: good){
            if (!i.isEmpty()) out.add(i);
        }
        System.out.println(out.size());
        for (String i: out) System.out.println(i);
    }
}
