package SixteenBitSWOnly;

import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());

        for (int i = 0; i < n; i++){
            String[] s = br.readLine().split(" ");
            long a = Long.parseLong(s[0]);
            long b = Long.parseLong(s[1]);
            long p = Long.parseLong(s[2]);

            if (a * b == p){
                System.out.println("POSSIBLE DOUBLE SIGMA");
            } else if (a * b != p){
                System.out.println("16 BIT S/W ONLY");
            }
        }
    }
}

