package Primes;

import java.util.*;

public class Main {
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        int num = 3;
        boolean isPrime = true;

        System.out.println(2);
        for (int i = 2; i <= n;){
            for (int j = 2; j <= Math.sqrt(num); j++){
                if (num % j == 0){
                    isPrime = false;
                    break;
                }
            }
            if (isPrime){
                System.out.println(num);
                i++;
            }
            isPrime = true;
            num++;
        }
    }
}
