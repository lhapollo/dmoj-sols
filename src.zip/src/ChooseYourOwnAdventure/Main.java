package ChooseYourOwnAdventure;

import java.io.*;
import java.util.*;

public class Main {
//    static int shortestPath(HashMap<Integer, ArrayList<Integer>> graph, int cur, int len, boolean[] visited){
//        len++;
//        visited[cur-1] = true;
//    }

    static boolean canVisit(HashMap<Integer, ArrayList<Integer>> graph, int n){
        boolean[] visited = new boolean[n];
        for (int node: graph.keySet()){
            visited[node-1] = true;
            for (int x: graph.get(node)) visited[x-1] = true;
        }
        for (boolean b: visited){
            if (!b) return false;
        }
        return true;
    }
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        HashMap<Integer, ArrayList<Integer>> graph = new HashMap<Integer, ArrayList<Integer>>();
        int n = Integer.parseInt(br.readLine());
        for (int i = 1; i <= n; i++){
            String[] line = br.readLine().split(" ");
            ArrayList<Integer> edges = new ArrayList<Integer>();
            for (int j = 0; j < Integer.parseInt(line[0]); j++){
                edges.add(Integer.parseInt(line[j+1]));
            }
            graph.put(i, edges);
        }
        System.out.println(canVisit(graph, n)? "Y":"N");
    }
}
