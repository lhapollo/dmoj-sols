package DereckandEssays;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] sentence = br.readLine().split(" ");
        String reverse = "";

        for (int i = 0; i < sentence.length; i++){
            String word = "";
            for (int j = sentence[i].length() - 1; j >=0 ; j--){
                word += sentence[i].charAt(j);
            }
            reverse += word + " ";
        }

        System.out.println(reverse);
    }
}
