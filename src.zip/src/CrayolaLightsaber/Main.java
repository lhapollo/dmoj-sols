package CrayolaLightsaber;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        HashMap<String,Integer> colours = new HashMap<String,Integer>();
        int n = Integer.parseInt(br.readLine());
        String[] line = br.readLine().split(" ");
        int maximum = 0;
        int r;
        for (int i = 0; i < n; i++){
            colours.put(line[i], colours.getOrDefault(line[i], 0) + 1);
        }
        for (int i: colours.values()){
            maximum = Math.max(maximum, i);
        }
        r = n - maximum;
        System.out.println(Math.min(r+1,maximum) + r);
    }
}
