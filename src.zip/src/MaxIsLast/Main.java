package MaxIsLast;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        double max = 0;
        double[] arr = new double[n];
        for (int i = 0; i < n ; i++){
            arr[i] = Double.parseDouble(br.readLine());
            if (arr[i] > max){
                max = arr[i];
            }
        }
        for(int i = 0; i < n; i++){
            if (arr[i] == max) continue;
            else System.out.printf("%.2f",arr[i]);
            System.out.println();
        }
        System.out.printf("%.2f",max);
    }
}
