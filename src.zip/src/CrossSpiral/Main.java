package CrossSpiral;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int w, l, rl, rw, s;
        w = Integer.parseInt(br.readLine());
        l = Integer.parseInt(br.readLine());
        rw = Integer.parseInt(br.readLine());
        rl = Integer.parseInt(br.readLine());
        s = Integer.parseInt(br.readLine());

        boolean[][] cross = new boolean[l][w];

        for (int i = 0; i < rl; i++) {
            for (int j = 0; j < rw; j++) {
                cross[i][j] = true;
            }
        }

        for (int i = 0; i < rl; i++) {
            for (int j = w - 1; j > w - 1 - rw; j--) {
                cross[i][j] = true;
            }
        }

        for (int i = l - 1; i > l - 1 - rl; i--) {
            for (int j = 0; j < rw; j++) {
                cross[i][j] = true;
            }
        }

        for (int i = l - 1; i > l - 1 - rl; i--) {
            for (int j = w - 1; j > w - 1 - rw; j--) {
                cross[i][j] = true;
            }
        }

        int x = 0, y = rw - 1; //starting pos
        boolean rightDown = true, downLeft = false, leftUp = false, upRight = false;

        int horizontal = 1; //moving right first
        int vertical = 1; //moving down first
        for (int i = 0; i < s; i++) {
            //case one: right, down (right priority)
            if (y + horizontal < w && x + vertical < l && y + horizontal >= 0 && x + vertical >= 0) {
                if (rightDown) {
                    if (!cross[x][y + horizontal]) y += horizontal;
                    else if (cross[x][y + horizontal] && !cross[x + vertical][y]) x += vertical;
                } else if (downLeft) {
                    if (!cross[x + vertical][y]) x += vertical;
                    else if (cross[x + vertical][y] && !cross[x][y + horizontal]) y += horizontal;
                } else if (leftUp){
                    if (!cross[x][y + horizontal]) y += horizontal;
                    else if (cross[x][y+horizontal] && !cross[x+vertical][y]) x+= vertical;
                }
                cross[x][y] = true;
            } else { //are on border
                System.out.println("on border");
                //direction switch
                if (rightDown) {
                    horizontal *= -1;
                    rightDown = false;
                    downLeft = true;
                } else if (downLeft){
                    vertical *= -1;
                    downLeft = false;
                    leftUp = true;
                } else if (leftUp){
                    upRight = true;
                    leftUp = false;
                    horizontal *= -1;
                }
            }
            System.out.println(x + " " + y);
            System.out.println(i);
        }

        //displaying grid
        for (int i = 0; i < l; i++) {
            for (int j = 0; j < w; j++) {
                System.out.print(cross[i][j] ? 1 : 0);
                System.out.print(" ");
            }
            System.out.println();
        }

    }
}
