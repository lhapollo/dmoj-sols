package WrongDereck;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String sentence = br.readLine();
        String[] words;

        boolean javaSentence = false;
        boolean cppSentence = false;
        boolean dereckSentence = false;

        sentence = sentence.replace('3', 'e');
        sentence = sentence.replace('5', 's');
        sentence = sentence.replace('@', 'a');
        sentence = sentence.replace('7', 't');
        sentence = sentence.replace('1', 'i');

        String lettersOnly = sentence.replaceAll("[\\W]", " ");

        words = lettersOnly.split(" ");

        for (String word: words){
            if (word.length() >= 6){
                //System.out.println(word);
                for (int i = 0; i < word.length() - 5; i++){
                    char[] substring = word.substring(i, i+6).toCharArray();
                    Arrays.sort(substring);
                    String updated = new String(substring);
                    //System.out.println(updated);
                    if (updated.equals("cdeekr")){
                        dereckSentence = true;
                        break;
                    }
                }
            }
        }

        if (sentence.contains("biginteger") || sentence.contains("apics")) {
            javaSentence = true;
        } else if (sentence.contains("segmentation") || sentence.contains("fault")){
            cppSentence = true;
        }

        if ((dereckSentence && javaSentence) || (!dereckSentence && cppSentence)){
            System.out.println("Right Dere(c)k!");
        } else if ((dereckSentence && cppSentence) || (!dereckSentence && javaSentence))
            System.out.println("Wrong Dere(c)k!");
    }
}
