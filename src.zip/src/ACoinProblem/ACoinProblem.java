package ACoinProblem;

import java.io.*;
import java.util.Arrays;

public class ACoinProblem {
    static int[] possible;
    static void initialize(int[] array){
        Arrays.fill(array, -1);
    }
    static int s(int S, int[] coins){
        if (S < 0) return -1;
        else if (S == 0) return 0;
        if (possible[S-1] == -1){
            for (int coin: coins) {
                if (possible[S-1] == 0) break;
                else possible[S-1] *= s(S-coin, coins);
            }
        } else if (possible[S-1] != -1) return possible[S-1];
        return possible[S-1];
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), s = Integer.parseInt(line[1]);
        int[] cents = new int[n];
        possible = new int[s];
        line = br.readLine().split(" ");
        for (int i = 0; i < n; i++){
            cents[i] = Integer.parseInt(line[i]);
        }
        initialize(possible);
//        System.out.println(s(s,cents));
//        System.out.println(Arrays.toString(possible));
        if (s(s, cents) == 0){
            System.out.println("YES");
        } else System.out.println("NO");
    }
}
