package AddingReversedNumbers;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        for (int i = 0; i < n; i++){
            String in = br.readLine();
            String reverse = "";
            for (int j = in.length() - 1; j >= 0; j--){
                reverse += in.charAt(j);
            }
            String[] arr = reverse.split(" ");
            long sum = Long.parseLong(arr[0]) + Long.parseLong(arr[1]);
            String reverseSum = "", stringSum = ""+sum;
            for (int j = stringSum.length()-1; j >= 0; j--){
                reverseSum += stringSum.charAt(j);
            }
            long out = Long.parseLong(reverseSum);
            System.out.println(out);
        }

    }
}
