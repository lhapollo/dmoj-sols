package Factors;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        long a = Long.parseLong(line[0]), b = Long.parseLong(line[1]);
        long sum = ((a+b)*(b-a+1))/2;
        long factors = 0;

        int increment = sum % 2 == 0 ? 1 : 2;

        for (int i = 1; i <= Math.sqrt(sum); i+= increment){
            if (sum % i == 0) {
                factors ++;
                if (i != sum / i) {
                    factors ++;
                }
            }
        }

        System.out.println(factors);
    }
}
