package BillsBillsBills;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String account = " ";
        int start = 0, end = 0;
        while (account.charAt(0) != '-'){
            account = br.readLine();
            if (account.charAt(0) == '-') break;
            double bill = 0;
            String[] line = br.readLine().split(" ");
            start = Integer.parseInt(line[0]);
            end = Integer.parseInt(line[1]);
            if (end < start) end += 10000;
            int diff = end - start;
            if (diff <= 10) bill = 6.59;
            else if (diff <= 30) bill = 6.59 + (diff - 10) * 0.2373;
            else if (diff <= 85) bill = 11.336 + (diff - 30) * 0.2271;
            else if (diff <= 170) bill = 23.8265 + (diff - 85) * 0.2178;
            else bill =  42.3395 + (diff - 170) * 0.2085;

            System.out.println("Account #: " + account);
            System.out.printf("Bill: %.2f", bill);
            System.out.println();
        }
    }
}
