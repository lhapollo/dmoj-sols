package Distance;

import java.util.*;
import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), q = Integer.parseInt(line[1]);
        line = br.readLine().split(" ");
        long[] num = new long[n];
        for (int i = 0; i < n ; i++){
            num[i] = Long.parseLong(line[i]);
        }
        Arrays.sort(num);
        for (int i = 0; i < q; i++){
            long number = Long.parseLong(br.readLine());
            int index = Arrays.binarySearch(num, number);
            if (index < 0){
                if (index == -1){
                    System.out.println(num[0]);
                } else if (Math.abs(index) == num.length + 1){
                    System.out.println(num[Math.abs(index) - 2]);
                } else {
                    long d1 = Math.abs(num[Math.abs(index)-2] - number);
                    long d2 = Math.abs(num[Math.abs(index)-1] - number);

                    if (d1 < d2) System.out.println(num[Math.abs(index)-2]);
                    else if (d2 < d1) System.out.println(num[Math.abs(index)-1]);
                    else System.out.println(Math.max(num[Math.abs(index)-2], num[Math.abs(index)-1]));
                }
            } else {
                System.out.println(num[index]);
            }
        }
    }
}
