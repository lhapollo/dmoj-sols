package IntertwinedStrings;

import java.io.*;
import java.util.*;

public class Main {
    static HashSet<String> all = new HashSet<String>();

    static void solve(String s1, int i, String s2, int j, String curr){
        //if we use up all letters in both strings
        if (i == s1.length() && j == s2.length()) all.add(curr);
        if (i < s1.length()) solve(s1, i+1, s2, j, curr + s1.charAt(i));
        if (j < s2.length()) solve(s1,i,s2,j+1,curr + s2.charAt(j));
    }

    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        solve(line[0], 0, line[1], 0, "");
        for (String s: all){
            System.out.println(s);
        }
    }
}
