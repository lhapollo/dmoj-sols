package AbsolutelyAcidic;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        HashMap<Integer, Integer> count = new HashMap<>();
        ArrayList<Integer> frequencies = new ArrayList<>();
        TreeSet<Integer> seconds = new TreeSet<>();
        int n = Integer.parseInt(br.readLine());
        for (int i = 0; i < n; i++){
            int x = Integer.parseInt(br.readLine());
            count.put(x, count.getOrDefault(x, 0)+1);
        }
        for (int f: count.values()){
            frequencies.add(f);
        }
        Collections.sort(frequencies);
        int temp = frequencies.get(frequencies.size()-1);
        //if only one largest frequency
        frequencies.remove(Integer.valueOf(temp));
        if (!frequencies.contains(temp)){
            int second = frequencies.get(frequencies.size()-1);
            for (int i: count.keySet()) if (count.get(i) == second) seconds.add(i);
            ArrayList<Integer> treeOut = new ArrayList<Integer>(seconds);
            for (int i: count.keySet()){
                if (count.get(i) == temp){
                    int one = Math.abs(i- treeOut.get(0));
                    int two = Math.abs(i - treeOut.get(treeOut.size()-1));
                    System.out.println(Math.max(one, two));
                    break;
                }
            }
        } else {
            for (int i: count.keySet()) if (count.get(i) == temp) seconds.add(i);
            ArrayList<Integer> out = new ArrayList<Integer>(seconds);
            System.out.println(Math.abs(out.get(0) - out.get(out.size()-1)));
        }
    }
}
