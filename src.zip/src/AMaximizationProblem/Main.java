package AMaximizationProblem;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        long n = Long.parseLong(br.readLine());
        long a = 0, b = 0, c = 0;

        if (n % 3 == 0) {
            a = n / 3;
            b = n / 3;
            c = n / 3;
        } else if (n % 3 == 1) {
            a = n / 3;
            b = n / 3;
            c = n / 3 + 1;
        } else if (n % 3 == 2) {
            a = n / 3 + 1;
            b = n / 3 + 1;
            c = n / 3;
        }
        System.out.println((a * b * c) + (a * b) + (a * c) + (b * c));
    }
}

