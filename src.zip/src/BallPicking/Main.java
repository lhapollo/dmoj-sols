package BallPicking;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), m = Integer.parseInt(line[1]), q = Integer.parseInt(line[2]);
        HashMap<String, ArrayList<Long>> map = new HashMap<>();
        for (int i = 0; i < n; i++){
            line = br.readLine().split(" ");
            String s = line[0];
            long a = Integer.parseInt(line[1]);
            ArrayList<Long> l = new ArrayList<>(map.getOrDefault(s, new ArrayList<Long>()));
            l.add(a);
            map.put(s, l);
        }
        ArrayList<ArrayList<Long>> psa = new ArrayList<>();
        ArrayList<Long> totalPsa = new ArrayList<>();
        for (ArrayList<Long> al: map.values()){
            al.sort(Collections.reverseOrder());
            ArrayList<Long> sums = new ArrayList<>();
            sums.add(al.get(0));
            for (int i = 1; i < al.size(); i++){
                sums.add(al.get(i)+sums.get(i-1));
            }
        }
        for (int i = 0; i < q; i++){
            long out = 0;
            int k = Integer.parseInt(br.readLine());
            for (ArrayList<Long> list : psa){
                out += list.get(Math.min(k-1, list.size()-1));
            }
            //System.out.println(out);
        }
//        System.out.println(map);
        System.out.println(psa);
    }
}