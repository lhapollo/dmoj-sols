package WhenInRome;

import java.io.*;
import java.util.*;

public class Main {
    static int convert(String number){
        HashMap<Character,Integer> chars = new HashMap<>();
        chars.put('I',1);
        chars.put('V',5);
        chars.put('X',10);
        chars.put('L',50);
        chars.put('C',100);
        chars.put('D',500);
        chars.put('M',1000);

        int result = 0;

        for (int i = 0; i < number.length(); i++){
            char c = number.charAt(i);
            if (i > 0 && chars.get(c) > chars.get(number.charAt(i-1))){
                result += chars.get(c) - 2*chars.get(number.charAt(i-1));
            }
            else {
                result += chars.get(c);
            }
        }
        return result;
    }
    static String intToRoman(int num)
    {
        // storing roman values of digits from 0-9
        // when placed at different places
        String m[] = { "", "M", "MM", "MMM" };
        String c[] = { "",  "C",  "CC",  "CCC",  "CD",
                "D", "DC", "DCC", "DCCC", "CM" };
        String x[] = { "",  "X",  "XX",  "XXX",  "XL",
                "L", "LX", "LXX", "LXXX", "XC" };
        String i[] = { "",  "I",  "II",  "III",  "IV",
                "V", "VI", "VII", "VIII", "IX" };

        // Converting to roman
        String thousands = m[num / 1000];
        String hundreds = c[(num % 1000) / 100];
        String tens = x[(num % 100) / 10];
        String ones = i[num % 10];

        String ans = thousands + hundreds + tens + ones;

        return ans;
    }
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(br.readLine());
        for (int i = 0; i < t; i++){
            String line = br.readLine();
            String ans;
            line = line.replace("+"," ").replace("="," ");
            String[] add = line.split(" ");
            int first = convert(add[0]), second = convert(add[1]);
            int out = first + second;
            ans = (out > 1000? "CONCORDIA CUM VERITATE": intToRoman(out));
            System.out.println(add[0]+"+"+add[1]+"="+ans);
        }
    }
}
