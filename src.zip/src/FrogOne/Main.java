package FrogOne;

import java.io.*;

public class Main {
    static int dp(int start, int[] array, int[] dpArr){
        if (start == 0 || start == 1) return dpArr[start];
        else if (dpArr[start] != Integer.MAX_VALUE) return dpArr[start];

        int c2 = dp(start-2,array,dpArr) + Math.abs(array[start]-array[start-2]);
        int c1 = dp(start-1, array, dpArr) + Math.abs(array[start] - array[start-1]);
        int amt = Math.min(c2,c1);

        dpArr[start] = amt;
        return amt;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        int[] memo = new int[n+1], arr = new int[n+1];
        arr[0] = Integer.MAX_VALUE;
        memo[0] = 0;
        memo[1] = 0;
        String[] line = br.readLine().split(" ");
        for (int i = 2; i < memo.length; i++) memo[i] = Integer.MAX_VALUE;
        for (int i = 1; i <= n; i++){
            arr[i] = Integer.parseInt(line[i-1]);
        }
        System.out.println(dp(n,arr,memo));
    }
}
