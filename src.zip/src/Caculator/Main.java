package Caculator;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        ArrayList<String> values = new ArrayList<>();
        int t = Integer.parseInt(reader.readLine());
        for (int i = 0; i < t; i++){
            int b1 = Integer.parseInt(reader.readLine());
            int a =  Integer.parseInt(reader.readLine() , b1);
            int b2 = Integer.parseInt(reader.readLine());
            int b = Integer.parseInt(reader.readLine(), b2);
            String num = "";

            char operand = reader.readLine().charAt(0);
            int bf = Integer.parseInt(reader.readLine());
            reader.readLine();

            switch (operand) {
                case '+':
                    num = Integer.toString(Integer.parseInt(""+(a + b), 10), bf);
                    break;
                case '-':
                    num =  Integer.toString(Integer.parseInt(""+(a - b), 10), bf);
                    break;
                case '*':
                    num =  Integer.toString(Integer.parseInt(""+(a * b), 10), bf);
                    break;
                case '/':
                    num =  Integer.toString(Integer.parseInt(""+(a / b), 10),bf);
                    break;
            }

            values.add(num);
        }

        for(String value: values){
            System.out.println(value);
        }
    }
}
