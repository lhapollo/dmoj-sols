package WhenYouEatYourSmarties;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        for (int i = 0; i < 10; i++){
            int total = 0;
            HashMap<String, Integer> count = new HashMap<>();
            String s = "";
            while (!s.equals("end of box")){
                s = br.readLine();
                if (s.equals("end of box")) break;
                count.put(s, count.getOrDefault(s, 0) + 1);
            }
            for (String a: count.keySet()){
                int x = count.get(a);
                if (a.equals("red")){
                    total += x * 16;
                } else {
                    if (x % 7 == 0) total += (x/7) * 13;
                    else total += (x/7)*13 + 13;
                }
            }
            System.out.println(total);
        }
    }
}
