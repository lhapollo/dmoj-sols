package GraphTheory3;

import java.io.*;
import java.util.*;

public class Main {
    static int graphTheory(int start, ArrayList<ArrayList<Integer>> graph, boolean[] status){
        int max = 0;
        max++;
        status[start-1] = true;
        for (int links: graph.get(start-1)){
            //if (!status[links-1]) max
        }
        return max;
    }
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), k = Integer.parseInt(line[1]);
        ArrayList<ArrayList<Integer>> graph = new ArrayList<ArrayList<Integer>>();
        boolean[] visited = new boolean[n];
        for (int i = 1; i <= n; i++){
            graph.add(new ArrayList<Integer>());
        }
        //getting links from graph
        for (int i = 0; i < n-1; i++){
            line = br.readLine().split(" ");
            graph.get(Integer.parseInt(line[0])).add(Integer.parseInt(line[1]));
            graph.get(Integer.parseInt(line[1])).add(Integer.parseInt(line[0]));
        }
    }
}
