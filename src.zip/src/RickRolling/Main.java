package RickRolling;

import java.io.*;
import java.util.*;

public class Main {
    //49QQWXcdgww -> length 11
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String input = br.readLine();
        char[] sorted = "dQw4w9WgXcQ".toCharArray();
        Arrays.sort(sorted);
        String link = new String(sorted);
        boolean troll = false;
        if (input.length() < 11) troll = false;
        else{
            for (int i = 0; i <= input.length() - 11; i++){
                char[] sub = input.substring(i,i+11).toCharArray();
                Arrays.sort(sub);
                String str = new String(sub);
                //System.out.println(str);
                if (str.equals(link)){
                    troll = true;
                    break;
                }
            }
        }
        if (troll) System.out.println("rickroll");
        else System.out.println("not a rickroll");
    }
}
