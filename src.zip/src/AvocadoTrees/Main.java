package AvocadoTrees;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), q = Integer.parseInt(line[1]), h = Integer.parseInt(line[2]);
        int[] heights = new int[n];
        int[] scores = new int[n];
        long[] psa = new long[n+1];
        psa[0] = 0;
        long max = 0;
        long score = 0;

        for (int i = 0; i < n; i++){
            line = br.readLine().split(" ");
            heights[i] = Integer.parseInt(line[0]);
            scores[i] = Integer.parseInt(line[1]);
            if (heights[i] <= h) {
                score += scores[i];
            }
            psa[i+1] = score;
        }
        for (int i = 0;i < q; i++){
            score = 0;
            line = br.readLine().split(" ");
            int l = Integer.parseInt(line[0]), r = Integer.parseInt(line[1]);
            if (l == 1){
                score = psa[r];
            } else {
                score = psa[r] - psa[l-1];
            }

            max = Math.max(score, max);
        }
//        System.out.println(Arrays.toString(psa));
        System.out.println(max);
//        System.out.println(Arrays.toString(heights));
//        System.out.println(Arrays.toString(scores));
    }
}
