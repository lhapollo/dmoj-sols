package UnevenSand;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        long left = 1;
        long right = 2000000000;
        String guess = "";
        int numGuess = 0;
        while (!guess.equals("OK") && numGuess <= 31) {
            long botGuess = (right + left) / 2;
            System.out.println(botGuess);
            System.out.flush();
            guess = br.readLine();
            if (guess.equals("SINKS")) {
                left = botGuess;
            } else if (guess.equals("FLOATS")) {
                right = botGuess;
            }
            numGuess++;
        }
    }
}
