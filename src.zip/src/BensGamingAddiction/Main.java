package BensGamingAddiction;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        TreeSet<String> words = new TreeSet<String>();
        for (int i = 0; i < n; i++){
            String s = br.readLine();
            words.add(s);
        }
        //System.out.println(words);
        int q = Integer.parseInt(br.readLine());
        for (int i = 0; i < q; i++){
            String sub = br.readLine();
            int len = -1;
            String ans = "";
            for (String w: words){
                if (w.contains(sub)){
                    if (len < w.length()){
                        len = w.length();
                        ans = w;
                    }
                }
            }
            System.out.println(len != -1? ans:-1);
        }
    }
}
