package HowManyZeros;

import java.io.*;

public class Main {
    static int count(int num){
        int zeros = 0;
        for (int i = 5; num/i > 0; i*=5){
            zeros += num/i;
        }
        return zeros;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        for (int i = 0; i < n; i++){
            int f = Integer.parseInt(br.readLine());
            System.out.println(count(f));
        }
    }
}
