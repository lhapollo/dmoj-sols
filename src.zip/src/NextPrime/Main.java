package NextPrime;

import java.io.*;

public class Main {
    public static boolean isPrime(int number){
        for (int i = 2; i <= Math.sqrt(number); i++){
            if (number % i == 0){
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());

        if (n == 1){
            n++;
        }

        while (!(isPrime(n))){
            n++;
        }

        System.out.println(n);
    }
}
