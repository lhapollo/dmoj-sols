package Siege;

import java.io.*;

public class Main {
    static long breach (int start, int end, int[][] array){
        //4 loops (one on each side)
        long min = 10000000;
        for (int i = start; i < end; i++){
            min = Math.min(array[start][i], min);
        }
        for (int i = start; i < end; i++){
            min = Math.min(array[end][i], min);
        }
        for (int i = start; i < end; i++){
            min = Math.min(array[i][start], min);
        }
        for (int i = start; i < end; i++){
            min = Math.min(array[i][end], min);
        }
        return min;
    }
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        int[][] arr = new int[n*2][n*2];
        String[] line;
        long time = 0;
        for (int i = 0; i < 2*n; i++){
            line = br.readLine().split(" ");
            for (int j = 0; j < 2*n; j++){
                arr[i][j] = Integer.parseInt(line[j]);
            }
        }
        for (int i =0; i < n; i++){
            time += breach(i, ((2*n)-i-1), arr);
        }
        System.out.println(time);
    }
}
