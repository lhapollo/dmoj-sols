package KeepingScore;

import java.util.*;

public class Main {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String hand = sc.nextLine();
        int c = -1, d=-1, h=-1, s=-1;
        for (int i = 0; i < hand.length(); i++){
            if (hand.charAt(i) == 'C') c = i;
            else if (hand.charAt(i) == 'D') d = i;
            else if (hand.charAt(i) == 'H') h = i;
            else if (hand.charAt(i) == 'S') s = i;
        }
        String clubs = hand.substring(c, d);
        String diamonds = hand.substring(d, h);
        String hearts = hand.substring(h, s);
        String spades = hand.substring(s);

        clubs = clubs.replace("C", "");
        diamonds = diamonds.replace("D", "");
        hearts = hearts.replace("H", "");
        spades = spades.replace("S", "");

        HashMap<String, Integer>  values = new HashMap<String, Integer>();
        values.put(clubs, 0);
        values.put(diamonds, 0);
        values.put(hearts, 0);
        values.put(spades, 0);

        for (String a: values.keySet()){
            if (a.length() == 0) values.put(a, 3);
            else if (a.length() == 1) values.put(a, 2);
            else if (a.length() == 2) values.put(a, 1);
            for (int i = 0; i < a.length(); i++){
                if (a.charAt(i) == 'A') values.put(a, values.get(a) + 4);
                if (a.charAt(i) == 'K') values.put(a, values.get(a) + 3);
                if (a.charAt(i) == 'Q') values.put(a, values.get(a) + 2);
                if (a.charAt(i) == 'J') values.put(a, values.get(a) + 1);
            }
        }


        System.out.println(values);
    }
}
