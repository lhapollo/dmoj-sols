package BobsRocks;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        String[] line = br.readLine().split(" ");
        int value = 0, year = 0;
        HashMap<Integer, Integer> ageValues = new HashMap<Integer, Integer>();
        for(int i = 0; i < n; i++){
            ageValues.put(Integer.parseInt(line[i]), ageValues.getOrDefault(Integer.parseInt(line[i]),0) + 1);
        }
        for (int a: ageValues.keySet()){
            if (a * ageValues.get(a) > value){
                value = a * ageValues.get(a);
                year = a;
            }
        }
        System.out.println(year);
    }
}
