package AllAboutAlliteration;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String character = br.readLine();
        char lower = Character.toLowerCase(character.charAt(0));
        char upper = Character.toUpperCase(character.charAt(0));
        ArrayList<String> substrings = new ArrayList<>();


        String substring = "";
        String sentence = br.readLine();
        String[] words = sentence.split(" ");

        for (String word: words){
            if (word.charAt(0) == upper || word.charAt(0) == lower){
                substring += word + " ";
            } else{
                substrings.add(substring);
                substring = substring.replace(substring, "");
            }
        }

        substrings.add(substring);

        Collections.sort(substrings,Collections.reverseOrder(Comparator.comparing(String::length)));
        System.out.println(substrings.get(0));
    }
}
