package AgeDemographic;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        TreeMap<Long, Long> map = new TreeMap<Long, Long>();
        int n = Integer.parseInt(br.readLine());
        String[] line = br.readLine().split(" ");
        long[] arr = new long[n];
        int c = 0;
        for (String s: line){
            long x = Long.parseLong(s);
            arr[c] = x;
            map.put(x, map.getOrDefault(x, (long) 0)+1);
            c++;
        }
        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));
        int q = Integer.parseInt(br.readLine());
        for (int i = 0; i < q; i++) {
            long a, b;
            line = br.readLine().split(" ");
            a = Long.parseLong(line[0]);
            b = Long.parseLong(line[1]);
            int low, high;
            low = Arrays.binarySearch(arr, a);
            high = Arrays.binarySearch(arr, b);
            if (low < 0) low = -low - 1;
            if (high < 0) high = -high - 1;
            System.out.println(low + " " + high);
        }

    }
}
