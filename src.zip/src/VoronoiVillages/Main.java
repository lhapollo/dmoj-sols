package VoronoiVillages;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        double[] arr = new double[n];
        for (int i = 0; i < n; i++){
            arr[i] = Double.parseDouble(br.readLine());
            arr[i] *= 1.0;
        }
        Arrays.sort(arr);
        double[] diffs = new double[n-1];
        for (int i = 0; i < n-1; i++){
            diffs[i] = (arr[i+1] + arr[i])/2.0;
        }
        double ans = Double.MAX_VALUE;
        for (int i = 1; i < n-1; i++){
            ans = Math.min(ans, (arr[i]-diffs[i-1]) + (diffs[i]-arr[i]));
        }
//        System.out.println(Arrays.toString(arr));
//        System.out.println(Arrays.toString(diffs));
        System.out.printf("%.1f", ans);
    }
}
