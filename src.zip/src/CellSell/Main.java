package CellSell;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int day, evening, weekend;
        double a = 0, b = 0;
        day = Integer.parseInt(br.readLine());
        evening = Integer.parseInt(br.readLine());
        weekend = Integer.parseInt(br.readLine());
        int dayA = Math.max(day - 100, 0);
        int dayB = Math.max(day - 250, 0);
        a += dayA * 0.25;
        b += dayB * 0.45;
        a += evening * 0.15;
        b += evening * 0.35;
        a += weekend * 0.20;
        b += weekend * 0.25;
        System.out.print("Plan A costs ");
        System.out.printf("%.2f",a);
        System.out.println();
        System.out.print("Plan B costs ");
        System.out.printf("%.2f",b);
        System.out.println();
        if (a == b) System.out.println("Plan A and B are the same price");
        else if (a > b) System.out.println("Plan B is cheapest.");
        else  System.out.println("Plan A is cheapest.");
    }
}
