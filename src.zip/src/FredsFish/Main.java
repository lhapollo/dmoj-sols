package FredsFish;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        HashMap<Integer, Integer> lakes = new HashMap<>();
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), m = Integer.parseInt(line[1]);
        int[] most = new int[n];
        int best = 0;
        double bestRatio = 0;
        for (int i = 0; i < m; i++){
            line = br.readLine().split(" ");
            lakes.put(Integer.parseInt(line[0]), lakes.getOrDefault(Integer.parseInt(line[0]), 0)+1);
            most[Integer.parseInt(line[0])-1] = Math.max(most[Integer.parseInt(line[0])-1], Integer.parseInt(line[1]));
        }

        for (int i: lakes.keySet()){
            double ratio = (most[i-1]*1.0)/ lakes.get(i);
            if (ratio > bestRatio){
                bestRatio = ratio;
                best = i;
            }
        }
        System.out.println(best);
    }
}
