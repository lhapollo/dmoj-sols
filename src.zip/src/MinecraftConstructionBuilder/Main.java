package MinecraftConstructionBuilder;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        double l = s.nextDouble();
        double w = s.nextDouble();
        double h = s.nextDouble();

        double a = w-2;
        double b = l-2;

        double sa = (2*l*h) + (2*a*h) + (a*b);
        double diamonds = 9 * sa;
        double time = diamonds / 32;

        System.out.printf("%.0f%n",Math.ceil(time));
    }
}
