package SpookyWords;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), q = Integer.parseInt(line[1]);
        String[] words = new String[n];
        for (int i = 0; i < n; i++){
            words[i] = br.readLine();
        }
        Arrays.sort(words);
        Arrays.sort(words, Comparator.comparingInt(String::length));

        for (int i = 0; i < q; i++){
            int pos = Integer.parseInt(br.readLine());
            System.out.println(words[pos-1]);
        }
    }
}
