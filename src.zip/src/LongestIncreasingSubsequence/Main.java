package LongestIncreasingSubsequence;

import java.util.*;

public class Main {
    //binary search to find the ceiling value
    static int ceilInd(int[] arr, int l, int r, int target){
        while (r - l > 1){
            int m = l + (r-l) / 2; //middle index
            if (arr[m] >= target) r = m;
            else l = m;
        }
        return r; //returning the index of ceiling key
    }

    static int LIS(int arr[], int size){
        //table to find tail values
        int[] table = new int[size];
        int len = 1;

        table[0] = arr[0];
        for (int i = 1; i < size; i++){
            if (arr[i] < table[0]) table[0] = arr[i]; //found the new smallest value
            else if (arr[i] > table[len-1]) table[len++] = arr[i]; //LIS extends
            else table[ceilInd(table, -1, len-1, arr[i])] = arr[i]; //replaces and discards other sequences of len+1 length
        }
        return len;
    }

    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++){
            arr[i] = s.nextInt();
        }
        System.out.println(LIS(arr, arr.length));
    }
}
