package TroublingTimes;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), d = Integer.parseInt(line[1]);
        int j = 10001;
        line = br.readLine().split(" ");
        int[] intervals = new int[n];
        for (int i = 0; i < n; i++){
            intervals[i] = Integer.parseInt(line[i]);
        }
        for (int interval : intervals){
            if (Math.abs(d) % interval == 0){
                if (Math.abs(d) / interval < j) j = Math.abs(d) / interval;
            }
        }
        if (j == 10001) System.out.println("This is not the best time for a trip.");
        else System.out.println(j);
    }
}
