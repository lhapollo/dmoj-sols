package SquareProblem;

import java.io.*;

public class Main {
    static boolean isPrime(long n) {
        if(n < 2) return false;
        if(n == 2 || n == 3) return true;
        if(n%2 == 0 || n%3 == 0) return false;
        long sqrtN = (long)Math.sqrt(n)+1;
        for(long i = 6L; i <= sqrtN; i += 6) {
            if(n%(i-1) == 0 || n%(i+1) == 0) return false;
        }
        return true;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(br.readLine());
        for (int i = 0; i < t; i++){
            String[] line = br.readLine().split(" ");
            long a = Long.parseLong(line[0]), b = Long.parseLong(line[1]);
            if (a - b != 1 || !isPrime(a+b)){
                System.out.println("NO");
            } else if (isPrime(a+b)){
                System.out.println("YES");
            }
        }
    }
}
