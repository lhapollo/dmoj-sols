package GoodColouring;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        String in = br.readLine();
        int change = 0, oneE = 0, oneO = 0, zeroE = 0, zeroO = 0;
        for (int i = 0; i < n; i++){
            if (i % 2 == 0){
                if (in.charAt(i) == '1') oneE++;
                else zeroE++;
            } else{
                if (in.charAt(i) == '1') oneO++;
                else zeroO++;
            }
        }
        if ((oneE + zeroO) > (zeroE+oneO)) change = zeroE + oneO;
        else change = oneE + zeroO;

        System.out.println(change);
    }
}
