package AssignmentOfTheYear;

import java.io.*;
import java.util.*;

public class Main {
    static HashSet<Integer> set = new HashSet<>();

    static void dp(String s, int val, int m){
        if (s.length() == 0){
            if (val < 0) return;
            else {
                set.add(m - val);
            }
        } else {
            for (int i = 1; i <= s.length(); i++){
                dp(s.substring(i), m - Integer.parseInt(s.substring(0, i)), m);
            }
        }
    }
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), m = Integer.parseInt(line[1]);
        String initial = br.readLine();
        dp(initial, m, m);
        System.out.println(set.size());
    }
}
