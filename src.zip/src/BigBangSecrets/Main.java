package BigBangSecrets;

import java.io.*;
//65-90

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int k = Integer.parseInt(br.readLine());
        String input = br.readLine();

        for (int i = 0; i < input.length(); i++){
            int s = 0;
        }
    }
}
