package AnExponentiationProblem;

import java.math.BigInteger;
import java.util.*;

public class Main {
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        long n = s.nextLong(), m = s.nextLong(), p = s.nextLong();
        BigInteger N = BigInteger.valueOf(n), M = BigInteger.valueOf(m), P = BigInteger.valueOf(p);

        BigInteger nm = N.modPow(M, P);
        System.out.println(nm);
    }
}
