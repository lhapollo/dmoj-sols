package NotEnoughTesters;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        //sieve
        int[] arr = new int[100001];
        List<Integer> bigArr[] = new ArrayList[100001];
        for (int i = 1; i <= arr.length-1; i++){
            bigArr[i] = new ArrayList();
            for (int j = i; j <= arr.length-1; j+= i){
                arr[j]++;
            }
            bigArr[arr[i]].add(i);
        }
        int t = Integer.parseInt(br.readLine());
        for (int i = t; t > 0; t--){
            String[] line = br.readLine().split(" ");
            int k = Integer.parseInt(line[0]);
            int a = Integer.parseInt(line[1]);
            int b = Integer.parseInt(line[2]);
            int l = Collections.binarySearch(bigArr[k], a);
            int r = Collections.binarySearch(bigArr[k], b);
            if (l < 0) l = -l -1;
            if (r < 0) r = -r -2;
            System.out.println(r-l+1);
        }
    }
}
