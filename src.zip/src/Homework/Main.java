package Homework;

import java.io.*;
import java.util.*;

public class Main {
    public static int[] vals = new int[10000000];

    public static boolean isPrime(int n){
        if (n == 1) return false;
        for (int i = 2; i <= Math.sqrt(n); i++){
            if (n % i == 0) return false;
        }
        return true;
    }

    public static void sieve(){
       for (int p = 1; p < 10000000; p++){
           if (isPrime(p)){
               for (int i = 1; i <= 10000000/p; i++){
                   vals[i*p-1]++;
               }
           }
       }
    }
    public static void main(String[] args) throws IOException{
        sieve();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(br.readLine());
        for (int i = 0; i < t; i++){
            int a, b;
            long k;
            int ans = 0;
            String[] line = br.readLine().split(" ");
            a = Integer.parseInt(line[0]);
            b = Integer.parseInt(line[1]);
            k = Long.parseLong(line[2]);
            for (int j = a; j <= b; j++){
                if (vals[j] == k) ans++;
            }
            System.out.println("Case #" + (i+1) + ": " + ans);
        }
    }
}
