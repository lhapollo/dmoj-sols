package BobAndHisCrops;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        String[] arr = br.readLine().split("w");
        int max = 0, p = 0, c = 0;
        for(String s: arr){
            if (s.length() > max){
                max = s.length();
                p = 0;
                c = 0;
                for (int i = 0; i < s.length(); i++){
                    if(s.charAt(i) == 'p') p++;
                    else c++;
                }
            }
        }
        System.out.println(p + " " + c);
    }
}
