package TooSpookyForMe;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]);
        long l = Long.parseLong(line[1]);
        long s = Long.parseLong(line[2]);
        long candy = l;

        ArrayList<Long> difference = new ArrayList<>();
        ArrayList<Long> psa = new ArrayList<>();

        for (int i = 0; i <= l; i++) difference.add((long) 0);

        for (int i = 0; i < n; i++){
            line = br.readLine().split(" ");
            difference.set(Integer.parseInt(line[0]) - 1, difference.get(Integer.parseInt(line[0])- 1)  + Long.parseLong(line[2]));
            difference.set(Integer.parseInt(line[1]), difference.get(Integer.parseInt(line[1])- 1)  - Long.parseLong(line[2]));
        }
        psa.add(difference.get(0));
//        System.out.println("difference: " + difference);
        for (int i = 1; i < l; i++){
            psa.add(psa.get(i-1) + difference.get(i));
            if (psa.get(i-1) + difference.get(i) >= s){
                candy--;
            }
        }
//        System.out.println("psa: " + psa);
        System.out.println(candy);


    }
}
