package AFractionProblem;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int a = Integer.parseInt(line[0]), b = Integer.parseInt(line[1]), c = Integer.parseInt(line[2]), d = Integer.parseInt(line[3]);

        System.out.print(a+c);
        System.out.print(" ");
        System.out.print(b+d);
    }
}
