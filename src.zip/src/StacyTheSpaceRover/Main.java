package StacyTheSpaceRover;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), m = Integer.parseInt(line[1]);
        double x = 0, y = 0;
        for (int i = 0; i < n; i++){
            line = br.readLine().split(" ");
            x += Double.parseDouble(line[0]);
            y += Double.parseDouble(line[1]);
        }
        boolean can = true;
        for (int i = 0; i < m; i++){
            double a, b;
            line = br.readLine().split(" ");
            a = Double.parseDouble(line[0]);
            b = Double.parseDouble(line[1]);
            double val = (y*a)/x;
            if (val == b){
                can = false;
                break;
            }
        }
        System.out.println(can?"yes":"no");
    }
}
