package SequenceProblem;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        String[] array = br.readLine().split(" ");

        Arrays.sort(array);
        int min = Math.abs(Integer.parseInt(array[0]) - Integer.parseInt(array[1]));

        for (int i = n-1; i > 0; i--){
            if (Math.abs(Integer.parseInt(array[i]) - Integer.parseInt(array[i-1])) < min){
                min = Math.abs(Integer.parseInt(array[n]) - Integer.parseInt(array[n-1]));
            }
        }

        System.out.println(min);
    }
}
