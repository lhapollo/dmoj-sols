package DerekandSnow;

import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
        double l = Double.parseDouble(b.readLine());
        double w = Double.parseDouble(b.readLine());
        double d = Double.parseDouble(b.readLine());
        double t = Double.parseDouble(b.readLine());

        double time = l * w * d * t;

        System.out.printf("%.1f", time);
    }
}
