package GreatSequence;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]);
        int k = Integer.parseInt(line[1]);
        int q = Integer.parseInt(line[2]);
        int[] arr = new int[n];
        HashMap<Integer, ArrayList<Integer>> indexes = new HashMap<Integer, ArrayList<Integer>>();
        line = br.readLine().split(" ");
        for (int i = 0; i < n; i++){
            arr[i] = Integer.parseInt(line[i]);
            indexes.put(arr[i], indexes.getOrDefault(arr[i], new ArrayList<>()));
            indexes.getOrDefault(arr[i], new ArrayList<>()).add(i+1);
        }
        long[] psa = new long[n+1];
        psa[0] = 0;
        for (int i = 1; i <= n; i++){
            psa[i] = psa[i-1] + arr[i-1];
        }
        System.out.println(indexes);
        for (int i = 0; i < q; i++){
            int a, b, x, y;
            line = br.readLine().split(" ");
            a = Integer.parseInt(line[0]);
            b = Integer.parseInt(line[1]);
            x = Integer.parseInt(line[2]);
            y = Integer.parseInt(line[3]);
            long sum = psa[y] - psa[x-1];
            if (sum <= k || !indexes.containsKey(a) || !indexes.containsKey(b)){
                System.out.println("No");
                continue;
            }
            int AindX = Collections.binarySearch(indexes.get(a), x);
            if (AindX < 0) AindX = -AindX-1;
            if (indexes.get(a).get(AindX) > y){
                System.out.println("No");
                continue;
            }
            int BindX = Collections.binarySearch(indexes.get(b), x);
            if (BindX < 0) BindX = -BindX-1;
            if (indexes.get(b).get(BindX) > y){
                System.out.println("No");
                continue;
            }
            System.out.println("Yes");

        }
    }
}
