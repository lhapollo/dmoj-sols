package OddTimes;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String number = br.readLine();
        if (Integer.parseInt(number) % 2 == 0){
            System.out.println("even");
        } else if (number.length() % 2 == 0){
            System.out.println("odd");
        } else if (number.length() % 2 == 1 && Integer.parseInt(number) % 2 == 1){
            System.out.println("very odd");
        }
    }
}
