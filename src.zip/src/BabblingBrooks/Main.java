package BabblingBrooks;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        ArrayList<Double> rivers = new ArrayList<Double>();
        int n = Integer.parseInt(br.readLine());
        for (int i = 0; i < n; i++){
            double d = Double.parseDouble(br.readLine());
            rivers.add(d);
        }
        int status = 0;
        while (status != 77){
            status = Integer.parseInt(br.readLine());
            if (status == 99){
                int index = Integer.parseInt(br.readLine());
                int percentage = Integer.parseInt(br.readLine());
                rivers.add(index, rivers.get(index-1) * (1-(0.01*percentage)));
                rivers.set(index-1, rivers.get(index-1) * (0.01*percentage));
            } else if (status == 88){
                int index = Integer.parseInt(br.readLine());
                rivers.set(index-1, rivers.get(index-1) + rivers.get(index));
                rivers.remove(index);
            }
        }
        for (double a: rivers){
            System.out.print(Math.round(a) + " ");
        }
    }
}
