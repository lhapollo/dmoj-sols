package PerfectTiming;

import java.io.*;
import java.util.*;
import java.time.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int x1 = Integer.parseInt(line[0]), y1 = Integer.parseInt(line[1]);
        line = br.readLine().split(" ");
        int x2 = Integer.parseInt(line[0]), y2 = Integer.parseInt(line[1]);
        String time = br.readLine();
    }
}
