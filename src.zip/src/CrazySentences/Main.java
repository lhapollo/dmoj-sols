package CrazySentences;

import java.io.*;
import java.util.*;

public class Main {
    static long dp(long num, long[] arr, long[] memo){
        long result = 0;
        if (num < 0) return 0;
        else if (num == 0) return 1;
        else if (memo[(int) num] != 0) return memo[(int) num];
        else {
            for (long i: arr){
                result += dp(num-i, arr, memo);
            }
        }
        memo[(int) num] = result;
        return result;
    }
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        long mod = 1000000007;
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), k = Integer.parseInt(line[1]);
        long[] arr = new long[n];
        long[] memo = new long[k+1];
        for (int i = 0; i < n; i++){
            String word = br.readLine();
            arr[i] = word.length();
        }
        System.out.println(dp(k,arr,memo) % mod);
    }
}
