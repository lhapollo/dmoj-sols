package ARecursionProblem;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s = br.readLine();
        s = s.replace("(+ ","").replace(")","").trim();
        String[] l = s.split(" ");
        long sum = 0;
        for (String str: l){
            str = str.trim();
            if (str.equals("")) continue;
            else {
                int a = Integer.parseInt(str);
                sum += a;
            }
        }
        System.out.println(sum);
    }
}
