package SquarePool;

import java.io.*;
import java.util.*;

public class Main {
    //method to test for valid coordinates
    static boolean goodCoordinates(int x, int y, int n){
        return (x > 0 && x <= n) && (y > 0 && y <= n);
    }
    //method to test for valid square
    static boolean goodSquare(int x1, int y1, int x2, int y2, int t, int n, int[][] trees){
        if (!goodCoordinates(x1,y1,n) || !goodCoordinates(x2,y2,n)) return false;
        for (int i = 0; i < t; i++){
            if (trees[i][0] >= x1 && trees[i][0] <= x2 && trees[i][1] >= y1 && trees[i][1] <= y2) return false;
        }
        return true;
    }
    //method for max square
    static int findMax(int n, int t, int[][] trees, HashSet<Integer> rows){
        int len = 0;
        for (int i : rows){
            for (int j = 1; j <= n; j++){
                while (len < n){
                    if (goodSquare(i, j, i + len, j + len, t, n, trees)) len++;
                    else break;
                }
            }
        }
        return len;
    }
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        int t = Integer.parseInt(br.readLine());
        int[][] trees = new int[t][2];
        HashSet<Integer> rows = new HashSet<Integer>();
        rows.add(1);
        //storing trees
        for (int i = 0; i < t; i++){
            String[] line = br.readLine().split(" ");
            trees[i][0] = Integer.parseInt(line[0]);
            trees[i][1] = Integer.parseInt(line[1]);
            rows.add(trees[i][0] + 1);
        }
        System.out.println(findMax(n,t,trees,rows));
    }
}
