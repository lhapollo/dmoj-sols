package ModernArt;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int m = Integer.parseInt(br.readLine()), n = Integer.parseInt(br.readLine()), k = Integer.parseInt(br.readLine());
        byte[] rows = new byte[m];
        byte[] cols = new byte[n];
        long output = 0;
        long sumR = 0, sumC = 0;
        for (int i = 0; i < k; i++) {
            String[] line = br.readLine().split(" ");
            if (line[0].equals("R")) {
                rows[Integer.parseInt(line[1])-1]++;
                rows[Integer.parseInt(line[1])-1]%= 2;
            } else if (line[0].equals("C")) {
                cols[Integer.parseInt(line[1])-1]++;
                cols[Integer.parseInt(line[1])-1]%=2;
            }
        }

        for (byte b: rows){
            sumR += b;
        }
        for (byte b: cols){
            sumC += b;
        }

        System.out.println((n*sumR) + (m*sumC) - (2*sumR*sumC));
    }
}
