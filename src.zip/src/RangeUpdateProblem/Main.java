package RangeUpdateProblem;

import java.io.*;

public class Main {
    // Creates a diff array D[] for A[] and returns
    // it after filling initial values.
    static void initializeDiffArray(long A[], long D[])
    {

        int n = A.length;

        D[0] = A[0];
        D[n] = 0;
        for (int i = 1; i < n; i++)
            D[i] = A[i] - A[i - 1];
    }

    // Does range update
    static void update(long D[], int l, int r, long x)
    {
        D[l-1] += x;
        D[r] -= x;
    }

    // Prints updated Array
    static int printArray(long A[], long D[])
    {
        for (int i = 0; i < A.length; i++) {

            if (i == 0)
                A[i] = D[i];

                // Note that A[0] or D[0] decides
                // values of rest of the elements.
            else
                A[i] = D[i] + A[i - 1];

            System.out.print(A[i] + " ");
        }

        System.out.println();

        return 0;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line  = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), q = Integer.parseInt(line[1]);
        line = br.readLine().split(" ");
        long[] arr = new long[n];
        long[] diff = new long[n+1];
        for (int i = 0; i < n; i++) {
            arr[i] = Long.parseLong(line[i]);
        }
        initializeDiffArray(arr, diff);

        for (int i = 0; i < q; i++){
            line = br.readLine().split(" ");
            int l = Integer.parseInt(line[0]), r = Integer.parseInt(line[1]);
            long v = Integer.parseInt(line[2]);
            update(diff, l, r, v);
        }
        printArray(arr, diff);

    }
}
