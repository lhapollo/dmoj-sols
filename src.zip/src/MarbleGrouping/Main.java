package MarbleGrouping;

import java.io.*;
import java.util.*;

public class Main {
    static void swap(int[] arr, int target){

    }
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), m = Integer.parseInt(line[1]);
        int[] distance = new int[m];
        int[] prevIndex = new int[m];
        for (int i = 0; i < m; i++) prevIndex[i] = -1;
        String[] list = br.readLine().split(" ");
    }
}