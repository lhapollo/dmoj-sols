package ConsonantsConsonance;

import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader b = new BufferedReader(new InputStreamReader(System.in));
        String[] sentence = b.readLine().split(" ");
        String newSentence = "";
        for (String s : sentence) {
            if (s.contains("A") || s.contains("a")) {
                s = s.replace("a", "");
                s = s.replace("A", "");
            }
            if (s.contains("E") || s.contains("e")) {
                s = s.replace("e", "");
                s = s.replace("E", "");
            }
            if (s.contains("I") || s.contains("i")) {
                s = s.replace("i", "");
                s = s.replace("I", "");
            }
            if (s.contains("O") || s.contains("o")) {
                s = s.replace("o", "");
                s = s.replace("O", "");
            }
            if (s.contains("U") || s.contains("u")) {
                s = s.replace("u", "");
                s = s.replace("U", "");
            }
            newSentence += s + " ";
        }
        System.out.println(newSentence);
    }
}
