package GuessingGame;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(br.readLine());
        for (int i = 0; i < t; i++){
            int guess1 = Integer.parseInt(br.readLine());
            int farOff1 = Integer.parseInt(br.readLine());
            int guess2 = Integer.parseInt(br.readLine());
            int farOff2 = Integer.parseInt(br.readLine());

            ArrayList<Integer> guesses = new ArrayList<Integer>();
            guesses.add(guess1 + farOff1);
            guesses.add(guess1 - farOff1);

            if (guesses.contains(guess2 + farOff2)) System.out.println(guess2 + farOff2);
            else System.out.println(guess2 - farOff2);
        }
    }
}
