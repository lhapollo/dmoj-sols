package ArrayDistances;

import java.io.*;
import java.math.*;

public class Main {
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] line = br.readLine().split(" ");
        int n = Integer.parseInt(line[0]), q = Integer.parseInt(line[1]);
        String[] array = br.readLine().split(" ");
        for(int i = 0; i < q; i++){
            long value = 0;
            int query = Integer.parseInt(br.readLine());
            int index = query;
            for (int j = 0; j < n; j++){
                int distance = Math.abs(index-j-1);
                long prod = Long.parseLong(array[j]) * distance;
                value += prod;
            }
            BigInteger output = BigInteger.valueOf(value).mod(BigInteger.valueOf(10).pow(9).add(BigInteger.valueOf(7)));
            System.out.println(output);
        }
    }
}
