package MirroredPairs;

import java.io.*;

/*
qp
pq
bd
db
nu ?

*/
public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Ready");
        String line = "";
        while (!line.equals("  ")){
            line = br.readLine();
            if (line.equals("  ")){
                break;
            }
            else if (line.equals("qp") || line.equals("pq") || line.equals("bd") || line.equals("db")){
                System.out.println("Mirrored Pair");
            } else if (!line.equals("  "))
                System.out.println("Ordinary Pair");
        }
    }
}
