package PeanutPlanning;

import java.io.*;
import java.util.*;

public class Main {
    static TreeMap<Integer, Integer> map = new TreeMap<>(); //mapping how many times an item occurs in the array

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        String[] in = br.readLine().split(" ");
        int n = Integer.parseInt(in[0]);
        int m = Integer.parseInt(in[1]);
        String[] nums = br.readLine().split(" ");
        for (int i = 0; i < n; i++) {
            int x = Integer.parseInt(nums[i]);
            map.put(x, map.getOrDefault(x, 0) + 1);
        }
        List<Integer> ans = new ArrayList<>();
        ans.add(map.firstKey()); //smallest keyset
        rem(map.firstKey());
        for (int i = 1; i < n; i++) {
            int last = ans.get(ans.size()-1);  //last item in the arrlist
            Integer t = map.ceilingKey(m - last); //smallest key >= m-last, ensures t + last >= m
            if (t == null) {
                System.out.println(-1); //if no such t, -1
                return;
            }
            ans.add(t); //else add t to the ans
            rem(t);
        }
        //print ans if exists
        for (int i = 0; i < n; i++) {
            System.out.print(ans.get(i) + (i == n-1? "\n":" "));
        }

    }
    static void rem(int x) { //removing one occurrence of x in the map
        if (map.get(x) == 1) {
            map.remove(x);
        }
        else {
            map.put(x, map.get(x)-1);
        }
    }
}
