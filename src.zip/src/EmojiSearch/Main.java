package EmojiSearch;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String sentence = br.readLine();
        ArrayList<String> emojis = new ArrayList<String>();
        String emoji = "";
        boolean openEmoji = false;

        for (int i = 0; i < sentence.length(); i++){
            if (sentence.charAt(i) == ':' && !openEmoji){
                openEmoji = true;
            } else if (openEmoji && sentence.charAt(i) != ':'){
                emoji += sentence.charAt(i);
            } else if (sentence.charAt(i) == ':' && openEmoji){
                openEmoji = false;
                emojis.add(emoji);
                emoji = emoji.replace(emoji, "");
            }
        }

        for (String e: emojis){
            System.out.println(e);
        }
    }
}
