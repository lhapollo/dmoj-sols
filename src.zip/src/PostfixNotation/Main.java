package PostfixNotation;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] arr = br.readLine().split(" ");
        ArrayList<String> order = new ArrayList<String>(Arrays.asList(arr));
        String ops = "*/+-%^";
        for (int i = 0; i < order.size(); i++){
            if (ops.contains(order.get(i))){
                String op = order.get(i);
                double a = Double.parseDouble(order.get(i-1)), b = Double.parseDouble(order.get(i-2));
                switch (op){
                    case "*":
                        b *= a;
                        break;
                    case "/":
                        b *= 1.0;
                        b /= a;
                        break;
                    case "+":
                        b += a;
                        break;
                    case "-":
                        b -= a;
                        break;
                    case "%":
                        b *= 1.0;
                        b %= a;
                        break;
                    case "^":
                        b = Math.pow(b, a);
                        break;
                }
                order.set(i-2, ""+b);
                order.remove(i-1);
                order.remove(op);
                i -= 2;
            }
        }
        System.out.printf("%.1f", Double.parseDouble(order.get(0)));
    }
}
